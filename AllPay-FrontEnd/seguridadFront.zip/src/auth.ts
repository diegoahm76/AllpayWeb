import NextAuth, { Session, User } from 'next-auth';
import { JWT } from 'next-auth/jwt';
import CredentialsProvider from 'next-auth/providers/credentials';
import axios from 'axios';
import { Exception } from '@/adapters/shared/exception';
import { Path, optionProtected } from '@/application/shared/path.enum';
import { Credentials } from '@/domain/auth/types/credentials.type';
import { AUTH_SECRET, NODE_ENV, BASE_API_URL } from '@/environment';
import { NextResponse } from "next/server";

const protectedRoutes = optionProtected;

export const { auth, signIn, signOut, unstable_update, handlers } = NextAuth({
  providers: [
    CredentialsProvider({
      name: 'credentials',
      async authorize(credentials: Partial<Record<string, unknown>>): Promise<User | null> {
        const payload = credentials as Credentials;
          
        try {
          const response = await axios.post(`${BASE_API_URL}users/login/`, {
            nombre_de_usuario: payload.user,
            password: payload.password
          }, {
            headers: { 'Content-Type': 'application/json' }
          }).catch((error) => error.response);
          if (response.data.success === false) {
            throw response.data.detail;
          }
          return response.data.data as User;
        } catch (error) {
          return new Exception(error as string);
        }
      }
    })
  ],
  debug: NODE_ENV === 'development',
  pages: {
    signIn: Path.Login,
    error: Path.Login
  },
  session: {
    strategy: 'jwt',
    maxAge: 1 * 24 * 60 * 60
  },
  jwt: {
    maxAge: 1 * 24 * 60 * 60
  },
  secret: AUTH_SECRET,
  callbacks: {
    async signIn(params): Promise<boolean | string> {
      try {
        const user = params.user as User;
        if (user.tokens?.access !== undefined) {
          return true;
        }
        throw params;
      } catch (error) {
        throw error;
      }
    },
    async jwt({ token, user }: { token: JWT; user: User }): Promise<null | JWT> {
      if (user) {
        token.id = user.id;
        token.user = user;
        token.permissions = user.permisos;
        token.persona_2fa = user.persona_2fa || [];
      }
      return token;
    },
    async session({ session, token }: { session: Session; token: JWT }): Promise<Session> {
      if (token.user) {
        session.user = token.user;
      }
      return session;
    },
    authorized(params): boolean | Response {
      const { auth, request } = params;
     
      if (!auth && protectedRoutes.some(obj => obj.link === request?.nextUrl?.pathname)) {
        const absoluteUrl = new URL("/auth/signin/", request.nextUrl.origin);
        return NextResponse.redirect(absoluteUrl.toString());
      }

      
      if (auth && (request?.nextUrl?.pathname === '/auth/signin/')) {
        const absoluteUrl = new URL("/", request.nextUrl.origin);
        return NextResponse.redirect(absoluteUrl.toString());
      }
      return NextResponse.next();
    }
  }
});
