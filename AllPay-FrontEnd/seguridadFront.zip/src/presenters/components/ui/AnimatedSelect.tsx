import React, { useState } from 'react';

interface FloatingSelectProps {
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  options: {
    key: string | number;
    value: string | number;
    title: string;
  }[];
  error?: boolean;
}

const AnimatedSelect: React.FC<FloatingSelectProps> = ({
  label,
  name,
  value,
  onChange,
  options,
  error,
}) => {
  const [isFocused, setIsFocused] = useState(false);

  const arrowDownPath = '/images/arrowDown.svg';
  const arrowUpPath = '/images/arrowUp.svg';

  return (
    <div className="relative w-full focus-within:border-green-700">
      {/* Label flotante */}
      <label
        className={`
    absolute left-3 px-1 transition-all pointer-events-none bg-white 
    ${isFocused || value ? 'top-[-10px] text-xs' : 'top-3 text-md'}
    ${error ? 'text-red-900 bg-red-50' : (isFocused || value ? 'text-[rgb(var(--green))]' : 'text-gray-500 bg-white')}
  `}
      >
        {label}
      </label>

      <select
        name={name}
        value={value}
        onChange={onChange}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        className={`
          w-full rounded-2xl border border-[#562707] p-3  outline-none appearance-none transition-all cursor-pointer text-md
          ${error
            ? 'bg-red-50 border border-red-500 text-red-900 placeholder-red-700 focus:ring-red-500 focus:border-red-500'
            : 'border-[#562707] text-[#562707]'
          }
        `}
        style={{
          backgroundImage: `url("${isFocused ? arrowUpPath : arrowDownPath}")`,
          backgroundPosition: 'right 1rem center',
          backgroundRepeat: 'no-repeat',
          backgroundSize: '1rem'
        }}
      >
        {!value && (
          <option value="" disabled hidden>
          </option>
        )}

        {options.map((opt, index) => (
          <option key={`${opt.key}-${index}`} value={opt.value}>
            {opt.title}
          </option>
        ))}
      </select>
    </div>
  );
};

export default AnimatedSelect;
