import React from 'react';
import { useTheme } from 'next-themes';

interface ModalContainerProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
}

const ModalContainer: React.FC<ModalContainerProps> = ({ isOpen, onClose, children }) => {
  const { theme } = useTheme();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-transparent bg-opacity-50 z-50 backdrop-blur">
      <div
        className={`bg-slate-200 p-6 w-full md:min-w-lg max-w-3xl rounded-xl shadow-md relative overflow-hidden`}
      >
        <div
          className={`bg-white rounded-xl p-6 shadow-md relative ${
            theme === 'dark' ? 'text-white' : 'text-[#562707]'
          }`}
          style={{
            maxHeight: '90vh', // Máxima altura del modal
            overflowY: 'auto' // Scroll vertical si es necesario
          }}
        >
          {/* Botón de cierre */}
          <button
            onClick={onClose}
            className={`absolute top-2 right-4 text-2xl hover:text-red-700 ${
              theme === 'dark' ? 'text-white' : 'text-[#562707]'
            }`}
          >
            &times;
          </button>

          {/* Contenido del modal */}
          {children}
        </div>
      </div>
    </div>
  );
};

export default ModalContainer;
