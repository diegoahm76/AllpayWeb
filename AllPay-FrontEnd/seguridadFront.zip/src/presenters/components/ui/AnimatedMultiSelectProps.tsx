import React, { useState } from 'react';
import {
  Select,
  MenuItem,
  Chip,
  Box,
  FormControl,
  InputLabel,
  OutlinedInput,
  SelectChangeEvent
} from '@mui/material';
interface Option {
    key: string | number;
    value: string | number;
    title: string;
  }
  
  interface AnimatedChipSelectProps {
    label: string;
    name: string;
    value: (string | number)[];
    onChange: (event: SelectChangeEvent<(string | number)[]>) => void | any ;
    options: Option[];
    error?: boolean;
    theme?: 'dark' | 'light';
  }
  
 
const AnimatedChipSelect: React.FC<AnimatedChipSelectProps> = ({
    label,
    name,
    value,
    onChange,
    options,
    error,
    theme = 'light'
  }) => {
    const [isFocused, setIsFocused] = useState(false);
    const [isOpen, setIsOpen] = useState(false);
  
    const isActive = isFocused || isOpen;
  
    const getColor = () => {
      if (error) return '#dc2626'; // rojo
      if (isActive) return '#4D750F'; // verde si está enfocado o abierto
      return '#562707'; // color base cuando no está desplegado
    };
  
    return (
      <FormControl fullWidth error={error} sx={{ mb: 2 }}>
        <InputLabel
          id={`${name}-label`}
          shrink
          sx={{
            color: getColor(),
            backgroundColor: theme === 'dark' ? '#1F2937' : 'white',
            px: 0.5,
            mx: 1,
            fontSize: '0.75rem',
            zIndex: 1,
            '&.Mui-focused': {
              color: getColor()
            }
          }}
        >
          {label}
        </InputLabel>
  
        <Select
          labelId={`${name}-label`}
          id={`${name}-select`}
          multiple
          value={value}
          onChange={onChange}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onOpen={() => setIsOpen(true)}
          onClose={() => setIsOpen(false)}
          input={<OutlinedInput notched />}
          renderValue={(selected) => (
            <Box
              sx={{
                display: 'flex',
                flexWrap: 'wrap',
                gap: 0.5,
                maxHeight: '100px',
                overflowY: 'auto'
              }}
            >
              {selected.map((val) => {
                const item = options.find(opt => opt.value === val);
                return (
                  <Chip
                    key={val}
                    label={item?.title || val}
                    sx={{
                      backgroundColor: theme === 'dark' ? '#374151' : '#E5E7EB',
                      color: theme === 'dark' ? 'white' : '#562707'
                    }}
                  />
                );
              })}
            </Box>
          )}
          sx={{
            borderRadius: '1rem',
            backgroundColor: theme === 'dark' ? '#1F2937' : 'white',
            color: getColor(),
            minHeight: '56px',
            '& .MuiOutlinedInput-notchedOutline': {
              borderColor: getColor()
            },
            '&:hover .MuiOutlinedInput-notchedOutline': {
              borderColor: getColor()
            },
            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
              borderColor: getColor()
            },
            '& .MuiSelect-icon': {
              color: getColor()
            }
          }}
          MenuProps={{
            PaperProps: {
              sx: {
                backgroundColor: theme === 'dark' ? '#1F2937' : 'white',
                color: theme === 'dark' ? 'white' : '#562707'
              }
            }
          }}
        >
          {options.map((opt) => (
            <MenuItem
              key={opt.key}
              value={opt.value}
              sx={{
                color: theme === 'dark' ? 'white' : '#562707',
                backgroundColor: theme === 'dark' ? '#1F2937' : 'white',
                '&:hover': {
                  backgroundColor: theme === 'dark' ? '#374151' : '#F3F4F6'
                }
              }}
            >
              {opt.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    );
  };
  
  export default AnimatedChipSelect;