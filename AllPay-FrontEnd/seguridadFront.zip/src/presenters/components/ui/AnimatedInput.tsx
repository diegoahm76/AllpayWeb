'use client';

import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import DatePicker, { registerLocale } from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { es } from 'date-fns/locale';
import { Month } from 'date-fns';

registerLocale('es', es);

interface AnimatedInputProps {
  label: string;
  name: string;
  value: string;
  id?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement | any>) => void;
  readOnly?: boolean;
  disabled?: boolean;
  required?: boolean;
  type?: 'text' | 'number' | 'password' | 'date' | 'email';
  error?: boolean;
  maxDate?: string;
  autoComplete?: 'on' | 'off' | 'new-password' | 'username' | 'email';
}

const AnimatedInput: React.FC<AnimatedInputProps> = ({
  label,
  name,
  id,
  value,
  onChange,
  readOnly = false,
  disabled = false,
  required = false,
  type = 'text',
  error,
  maxDate,
  autoComplete = 'on'
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const inputClassNames = `
    w-full p-3 rounded-2xl appearance-none placeholder-transparent transition-all text-[rgb(var(--brown))]
    ${disabled ? 'bg-gray-200 cursor-not-allowed' : 'cursor-pointer'}
    ${error
      ? 'bg-red-50 border border-red-500 text-red-900 placeholder-red-700 focus:ring-red-500 focus:border-red-500'
      : 'bg-white border border-brown text-brown'}
  `;

  const labelClassNames = `
    absolute left-3 px-1 transition-all pointer-events-none bg-white z-10
    ${isFocused || value ? 'top-[-10px] text-xs' : 'top-3 text-md'}
    ${error ? 'text-red-900 bg-red-50' : (isFocused || value ? 'text-[rgb(var(--green))]' : 'text-gray-500 bg-white')}
  `;

  const handleDateChange = (date: Date | null) => {
    if (onChange && date) {
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');

      const event = {
        target: {
          name,
          value: `${year}-${month}-${day}`,
          displayValue: `${day}/${month}/${year}`
        }
      } as any;
      onChange(event);
    }
  };

  // const formatDateForDisplay = (dateStr: string) => {
  //   if (!dateStr) return '';
  //   if (dateStr.includes('/')) return dateStr;
  //   const [year, month, day] = dateStr.split('-');
  //   return `${day}/${month}/${year}`;
  // };

  const parseDate = (dateStr: string): Date | null => {
    if (!dateStr) return null;

    let year, month, day;
    if (dateStr.includes('/')) {
      [day, month, year] = dateStr.split('/');
    } else {
      [year, month, day] = dateStr.split('-');
    }

    // Crear la fecha en la zona horaria local
    const date = new Date(Number(year), Number(month) - 1, Number(day), 12);
    return date;
  };

  return (
    <div className="relative w-full">
      <style jsx global>{`
        .react-datepicker-wrapper {
          display: block;
          width: 100%;
        }

        .react-datepicker__input-container {
          display: block;
          width: 100%;
        }

        .react-datepicker__input-container input {
          width: 100%;
        }

        .react-datepicker-popper {
          background-color: transparent;
          z-index: 9999 !important;
        }

        .datepicker-popper {
          z-index: 9999 !important;
        }

        .react-datepicker {
          font-family: inherit;
          border: 1px solid rgb(var(--green));
          border-radius: 1rem;
          background-color: white;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 
                      0 2px 4px -1px rgba(0, 0, 0, 0.06);
          z-index: 9999;
        }
        
        .react-datepicker__triangle {
          display: none;
        }

        .react-datepicker__header {
  
          padding: 0;
          position: relative;
          
          border-top-left-radius: 0 !important;
          border-top-right-radius: 0 !important;
          background-color: transparent !important;
          border-bottom: none !important;
        }

        .react-datepicker__month-container {
        }

        .react-datepicker__current-month {
          display: none;
        }

        .custom-select {
          color: rgb(75, 85, 99) !important;
          border: none !important;
          font-weight: 600;
          font-size: 1rem;
          cursor: pointer;
          padding: 0.2rem 1.5rem 0.2rem 0.5rem !important;
          -webkit-appearance: none;
          -moz-appearance: none;
          appearance: none;
          text-align: center;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='rgb(75, 85, 99)' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E") !important;
          background-repeat: no-repeat !important;
          background-position: right 2px center !important;
          background-size: 16px !important;
        }

        .custom-select option {
          color: rgb(var(--brown));
          background-color: white;
          padding: 4px 8px;
        }

        /* Estilos para el dropdown */
        .react-datepicker__header select {
          max-height: 200px !important;
          overflow-y: auto !important;
        }

        .react-datepicker__month-dropdown,
        .react-datepicker__year-dropdown {
          max-height: 120px !important; /* Altura reducida */
          overflow-y: auto !important;
        }

        select.custom-select option:hover {
          background-color: rgb(var(--gray-20));
          color: white;
        }

        /* Estilos para el scrollbar del dropdown */
        select.custom-select::-webkit-scrollbar {
          width: 6px;
        }

        select.custom-select::-webkit-scrollbar-track {
          background: #f1f1f1;
          border-radius: 4px;
        }

        select.custom-select::-webkit-scrollbar-thumb {
          background: #888;
          border-radius: 4px;
        }

        select.custom-select::-webkit-scrollbar-thumb:hover {
          background: #555;
        }

        .react-datepicker__day-names {
          text-color: black !important;
          padding: 0.5rem 0;
          border-bottom: 1px solid white;
          margin: 0;
          display: flex;
          justify-content: space-around;
        }

        .react-datepicker__day-name {
          color: rgb(75, 85, 99);
          font-weight: 500;
          width: 2rem;
          line-height: 2rem;
          margin: 0.2rem;
          text-align: center;
        }
        
        .react-datepicker__month {
          background-color: white;
          margin: 0;
          padding: 0.5rem 0;
        }

        .react-datepicker__week {
          display: flex;
          justify-content: space-around;
        }

        .react-datepicker__day {
          border-radius: 0.5rem;
          margin: 0.2rem;
          width: 2rem;
          line-height: 2rem;
          display: inline-flex;
          justify-content: center;
          align-items: center;
        }

        .react-datepicker__day:hover {
          background-color: rgba(var(--gray-40)) !important;
        }
        
        .react-datepicker__day--selected {
          background-color: rgb(var(--gray-20)) !important;
          color: white !important;
        }
        
        .react-datepicker__day--keyboard-selected {
        background-color: rgb(var(--gray-20)) !important;
          color: white;
        }

        .react-datepicker__day--disabled {
          color: #cbd5e0 !important;
          text-decoration: line-through;
          cursor: not-allowed;
        }

        .react-datepicker__day--disabled:hover {
          background-color: transparent !important;
        }

        .react-datepicker__navigation {
          display: none;
        }
        
        .react-datepicker__today-button {
          background-color: white;
          color: rgb(75, 85, 99);
          border: none;
          padding: 0.5rem;
          font-weight: 500;
          border-bottom-left-radius: 1rem;
          border-bottom-right-radius: 1rem;
          border-top: 1px solid rgb(229, 231, 235);
        }
      `}</style>

      <label className={labelClassNames}>
        {label}{required && ' *'}
      </label>

      {type === 'date' ? (
        <DatePicker
          selected={parseDate(value)}
          onChange={handleDateChange}
          dateFormat="dd/MM/yyyy"
          className={inputClassNames}
          name={name}
          id={id}
          disabled={disabled}
          required={required}
          maxDate={maxDate ? new Date(maxDate) : undefined}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(!!value)}
          autoComplete={autoComplete}
          todayButton="Hoy"
          showMonthDropdown
          showYearDropdown
          yearDropdownItemNumber={200}
          scrollableYearDropdown
          dropdownMode="select"
          placeholderText=""
          popperClassName="datepicker-popper"
          popperPlacement="bottom-start"
          locale="es"
          renderCustomHeader={({ date, changeYear, changeMonth }) => {
            const minYear = 1900;
            const maxYear = 2050;
            const years = Array.from({ length: maxYear - minYear + 1 }, (_, i) => minYear + i);
            return (
              <div className="flex items-center justify-center px-4 py-2">
                <div className="flex gap-2">
                  <select
                    value={date.getMonth()}
                    onChange={({ target: { value } }) => changeMonth(Number(value) as Month)}
                    className="custom-select"
                  >
                    {Array.from({ length: 12 }, (_, i) => i).map((month) => (
                      <option key={month} value={month}>
                        {es.localize?.month(month as Month, { width: 'wide' })}
                      </option>
                    ))}
                  </select>
                  <select
                    value={date.getFullYear()}
                    onChange={({ target: { value } }) => changeYear(Number(value))}
                    className="custom-select"
                  >
                    {years.reverse().map((year) => (
                      <option key={year} value={year}>
                        {year}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            );
          }}
        />
      ) : (
        <input
          type={type === 'password' ? (showPassword ? 'text' : 'password') : type}
          name={name}
          value={value}
          id={id}
          onChange={onChange}
          readOnly={readOnly}
          disabled={disabled}
          required={required}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(!!value)}
          autoComplete={autoComplete}
          spellCheck={type === 'password' ? 'false' : 'true'}
          {...(type === 'email' && { pattern: "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$" })}
          className={inputClassNames}
        />
      )}

      {type === 'password' && !disabled && (
        <button
          type="button"
          onClick={() => setShowPassword(!showPassword)}
          className={`
            absolute right-3 top-1/2 transform -translate-y-1/2 
            text-gray-500 hover:text-gray-700
          `}
        >
          {showPassword ? <Eye size={20} /> : <EyeOff size={20} />}
        </button>
      )}
    </div>
  );
};

export default AnimatedInput;
