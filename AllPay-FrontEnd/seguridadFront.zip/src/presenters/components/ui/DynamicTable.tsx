import React, { useState, useEffect } from 'react';
import { useTheme } from 'next-themes';
import { Pagination } from '@mui/material';
import * as XLSX from 'xlsx';
import Swal from 'sweetalert2';

interface Column {
    key: string;
    label: string;
    render?: (value: any, row: any) => React.ReactNode;
}

interface DynamicTableProps {
    columns: Column[];
    data: any[];
    currentPage: number;
    totalPages: number;
    onPageChange: (page: number) => void;
    actions?: {
        label: string;
        render: (row: any) => React.ReactNode;
    }[];
    isLoading?: boolean;
    onDownloadExcel?: () => Promise<any[]>;
    downloadButtonPosition?: 'top' | 'bottom';
}

const DynamicTable: React.FC<DynamicTableProps> = ({
    columns,
    data,
    currentPage,
    totalPages,
    onPageChange,
    actions,
    isLoading = false, // ya viene por defecto "false"
    onDownloadExcel,
    downloadButtonPosition = 'top'
}) => {
    const { theme } = useTheme();
    const [sortConfig, setSortConfig] = useState<{
        key: string;
        direction: 'asc' | 'desc';
    } | null>(null);

    useEffect(() => {
        if (columns.length > 0 && !sortConfig) {
            setSortConfig({ key: columns[0].key, direction: 'asc' });
        }
    }, [data, columns]);

    const handleSort = (key: string) => {
        if (sortConfig?.key === key) {
            setSortConfig({
                key,
                direction: sortConfig.direction === 'asc' ? 'desc' : 'asc'
            });
        } else {
            setSortConfig({ key, direction: 'desc' });
        }
    };

    const sortedData = [...data].sort((a, b) => {
        if (!sortConfig) return 0;

        const aValue = a[sortConfig.key]?.toString().toLowerCase() || '';
        const bValue = b[sortConfig.key]?.toString().toLowerCase() || '';

        if (sortConfig.direction === 'asc') {
            return aValue.localeCompare(bValue);
        } else {
            return bValue.localeCompare(aValue);
        }
    });

    const handleDownloadExcel = async () => {
        try {
            Swal.fire({
                title: 'Descargando Excel...',
                text: 'Por favor, espere mientras generamos el archivo.',
                allowOutsideClick: false,
                showConfirmButton: false,
                customClass: {
                    popup: 'swal2-no-border'
                },
                didOpen: () => {
                    Swal.showLoading();
                },
                footer: `
          <div style="display: flex; justify-content: center; margin-top: 10px;">
              <button id="closeButton" class="
                  w-[120px] py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
                  hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
                  flex items-center justify-center gap-2 outline-none focus:outline-none
              ">
                  Cerrar
              </button>
          </div>
        `,
                didRender: () => {
                    const closeButton = document.getElementById('closeButton');
                    if (closeButton) {
                        closeButton.addEventListener('click', () => Swal.close());
                    }
                }
            });

            let dataExcel = data;
            if (onDownloadExcel) {
                // Esta llamada ahora la controlas desde el padre con setIsExportLoading,
                // pero de todas maneras mantenemos la lógica del "Swal" aquí.
                dataExcel = await onDownloadExcel();
            }

            if (dataExcel.length === 0) {
                Swal.close();
                await Swal.fire({
                    icon: 'warning',
                    title: 'Sin datos para exportar',
                    text: 'No hay datos disponibles para generar el archivo.',
                    showConfirmButton: false,
                    timer: 2000
                });
                return;
            }

            const worksheet = XLSX.utils.json_to_sheet(dataExcel);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, 'Datos');
            XLSX.writeFile(workbook, 'Datos.xlsx');

            Swal.close();
            await Swal.fire({
                icon: 'success',
                title: 'Excel descargado correctamente',
                text: 'El archivo ha sido generado y descargado exitosamente.',
                showConfirmButton: false,
                timer: 2000
            });
        } catch (error) {
            Swal.close();
            await Swal.fire({
                icon: 'error',
                title: 'Error al descargar Excel',
                text: 'Ocurrió un error al generar el archivo Excel.',
                showConfirmButton: false,
                timer: 2000
            });
        }
    };

    const DownloadButton = () => (
        <button
            type="button"
            onClick={handleDownloadExcel}
            className="mt-4 block rounded-full border-none bg-transparent p-0 shadow-xl"
        >
            <img
                src="https://i.postimg.cc/rFZtRsTg/Grupo-1100.png"
                alt="Descargar Excel"
                className="h-10 w-10 cursor-pointer"
            />
        </button>
    );

    // Aquí decides cómo renderizar el "loading":
    if (isLoading) {
        // Podrías poner un spinner, un texto, un placeholder, etc.
        return (
            <div className="flex justify-center items-center w-full h-24">
                <p className="text-md font-semibold">
                    Cargando...
                </p>
            </div>
        );
    }

    return (
        <div className="w-full">
            <div className="flex justify-end mr-6 mb-6">
                {downloadButtonPosition === 'top' && <DownloadButton />}
            </div>

            <div className="w-full rounded-lg shadow-md overflow-hidden">
                <div className="overflow-x-auto scrollbar-custom">
                    <table className="w-full min-w-300 table-auto">
                        <thead>
                            <tr
                                className={`h-12 ${theme === 'dark'
                                    ? 'bg-[#562707] text-white'
                                    : 'bg-[#DEDEDE] text-[#562707]'
                                    }`}
                            >
                                {columns.map((column) => (
                                    <th
                                        key={column.key}
                                        className="text-left px-6 py-3 cursor-pointer hover:bg-opacity-80 transition-colors duration-200"
                                        onClick={() => handleSort(column.key)}
                                    >
                                        <div className="flex items-center gap-2 font-medium">
                                            {column.label.toUpperCase()}
                                            {sortConfig?.key === column.key && (
                                                <span className="text-md">
                                                    {sortConfig.direction === 'asc' ? '↑' : '↓'}
                                                </span>
                                            )}
                                        </div>
                                    </th>
                                ))}
                                {actions && (
                                    <th className="text-left px-6 py-3">
                                        <div className="font-medium">ACCIONES</div>
                                    </th>
                                )}
                            </tr>
                        </thead>
                        <tbody>
                            {sortedData.map((row, index) => (
                                <tr
                                    key={index}
                                    className={`h-10 border-b border-gray-200 transition-colors duration-200 text-md ${theme === 'dark'
                                        ? 'text-white hover:bg-[#562707]/20'
                                        : 'hover:bg-gray-50'
                                        }`}
                                >
                                    {columns.map((column) => (
                                        <td key={column.key} className="px-6 py-2">
                                            {column.render
                                                ? column.render(row[column.key], row)
                                                : row[column.key]}
                                        </td>
                                    ))}
                                    {actions && (
                                        <td className="px-6 py-3">
                                            <div className="flex items-center gap-3">
                                                {actions.map((action, actionIndex) => (
                                                    <React.Fragment key={actionIndex}>
                                                        {action.render(row)}
                                                    </React.Fragment>
                                                ))}
                                            </div>
                                        </td>
                                    )}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                <div
                    className={`px-6 py-4 flex justify-center border-t ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'
                        }`}
                >
                    <Pagination
                        count={totalPages}
                        page={currentPage}
                        disabled={isLoading}
                        onChange={(_event, page) => !isLoading && onPageChange(page)}
                        sx={{
                            '& .MuiPaginationItem-root': {
                                color: theme === 'dark' ? '#fff' : '#4D750F',
                                '&:hover': {
                                    backgroundColor:
                                        theme === 'dark'
                                            ? 'rgba(255, 255, 255, 0.1)'
                                            : 'rgba(77, 117, 15, 0.1)'
                                }
                            },
                            '& .MuiPaginationItem-page.Mui-selected': {
                                backgroundColor: '#4D750F',
                                color: 'white',
                                '&:hover': {
                                    backgroundColor: '#3d5d0c'
                                }
                            },
                            '& .MuiPaginationItem-previousNext': {
                                color: theme === 'dark' ? '#fff' : '#4D750F'
                            }
                        }}
                    />
                </div>
            </div>

            {downloadButtonPosition === 'bottom' && <DownloadButton />}

            <style jsx global>{`
        .scrollbar-custom::-webkit-scrollbar {
          height: 8px;
          width: 8px;
        }
        .scrollbar-custom::-webkit-scrollbar-track {
          background: ${theme === 'dark' ? '#1a1a1a' : '#f1f1f1'};
          border-radius: 4px;
        }
        .scrollbar-custom::-webkit-scrollbar-thumb {
          background: ${theme === 'dark' ? '#4D750F' : '#4D750F'};
          border-radius: 4px;
          transition: all 0.3s ease;
        }
        .scrollbar-custom::-webkit-scrollbar-thumb:hover {
          background: ${theme === 'dark' ? '#3d5d0c' : '#3d5d0c'};
        }
        .scrollbar-custom {
          scrollbar-width: thin;
          scrollbar-color: ${theme === 'dark'
                    ? '#4D750F #1a1a1a'
                    : '#4D750F #f1f1f1'};
        }
      `}</style>
        </div>
    );
};

export default DynamicTable;
