"use client";

import { useMemo, useState, useEffect } from "react";
import Swal from "sweetalert2";

let L: any = null;
if (typeof window !== "undefined") {
  L = require("leaflet");
}

export interface UseModalAddressProps {
  onClose: () => void;
  formData: any;
  setFormData: React.Dispatch<React.SetStateAction<any>>;
}

export function useModalAddress({ onClose, formData, setFormData }: UseModalAddressProps) {
  const [error, setError] = useState<string>("");
  const [mapReady, setMapReady] = useState(false);

  const customIcon = useMemo(() => {
    if (!L) return null;
    return new L.Icon({
      iconUrl: "/images/corporate/marker.png",
      iconSize: [30, 40],
      iconAnchor: [15, 40],
      popupAnchor: [0, -40]
    });
  }, []);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setFormData((prev: any) => ({
            ...prev,
            addressData: {
              ...prev.addressData,
              coordenadaX: { value: position.coords.latitude, error: false },
              coordenadaY: { value: position.coords.longitude, error: false }
            }
          }));
        },
        (error) => {
          console.error("Error al obtener la ubicación: ", error);
        }
      );
    }
    setMapReady(true);
  }, [setFormData]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const newValue = type === "checkbox" ? (e.target as HTMLInputElement).checked : value;

    setFormData((prev: any) => ({
      ...prev,
      addressData: {
        ...prev.addressData,
        [name]: {
          ...prev.addressData[name],
          value: newValue,
          error: false
        }
      }
    }));
    setError("");
  };

  const clear = () => {
    setFormData((prev: any) => ({
      ...prev,
      addressData: {
        ubicacion: { value: "", error: false },
        viaPrincipal: { value: "", error: false },
        nombreVia: { value: "", error: false },
        letraPrincipal: { value: "", error: false },
        letraPrincipal2: { value: "", error: false },
        prefijoBisPrincipal: { value: "", error: false },
        cordenadaPrincipal: { value: "", error: false },

        viaSecundaria: { value: "", error: false },
        nombreViaSecundaria: { value: "", error: false },
        letraSecundaria: { value: "", error: false },
        letraSecundaria2: { value: "", error: false },
        prefijoBisSecundaria: { value: "", error: false },
        cordenadaSecundaria: { value: "", error: false },

        viaTerciaria: { value: "", error: false },
        nombreViaTerciaria: { value: "", error: false },
        letraTerciaria: { value: "", error: false },
        letraTerciaria2: { value: "", error: false },
        prefijoBisTerciaria: { value: "", error: false },
        cordenadaTerciaria: { value: "", error: false },

        complemento: { value: "", error: false },

        coordenadaX: { value: 4.7, error: false },
        coordenadaY: { value: -74.09, error: false },
        location: { value: false, error: false }
      }
    }));
    setError("");
  };

  const save = () => {
    const addressData = formData.addressData;

    const ub = addressData.ubicacion.value;
    const vp = addressData.viaPrincipal.value;
    const nv = addressData.nombreVia.value;
    const lp = addressData.letraPrincipal.value;
    const lp2 = addressData.letraPrincipal2.value;
    const pfbp = addressData.prefijoBisPrincipal.value;
    const cdp = addressData.cordenadaPrincipal.value;

    const vs = addressData.viaSecundaria.value;
    const nvs = addressData.nombreViaSecundaria.value;
    const lsec = addressData.letraSecundaria.value;
    const lsec2 = addressData.letraSecundaria2.value;
    const pfbs = addressData.prefijoBisSecundaria.value;
    const cds = addressData.cordenadaSecundaria.value;

    const vs2 = addressData.viaTerciaria.value;
    const nvs2 = addressData.nombreViaTerciaria.value;
    const lter = addressData.letraTerciaria.value;
    const lter2 = addressData.letraTerciaria2.value;
    const pfbt = addressData.prefijoBisTerciaria.value;
    const cdt = addressData.cordenadaTerciaria.value;

    const comp = addressData.complemento.value;
    const coordX = addressData.coordenadaX.value;
    const coordY = addressData.coordenadaY.value;
    const location = addressData.location.value;

    let hasError = false;
    let title = "";

    if (!location) {
        const fieldsToValidate = [
          { key: "ubicacion", value: ub },
          { key: "viaPrincipal", value: vp },
          { key: "nombreVia", value: nv },
          { key: "nombreViaSecundaria", value: nvs },
          { key: "nombreViaTerciaria", value: nvs2 },
          
        ];
      
        fieldsToValidate.forEach(({ key, value }) => {
          if (value.trim() === "") {
            hasError = true;
            title = "Revise el formulario";
      
            setFormData((prev: any) => ({
              ...prev,
              addressData: {
                ...prev.addressData,
                [key]: {
                  ...prev.addressData[key],
                  error: true
                }
              }
            }));
          }
        });
      }

    if (hasError) {
      Swal.fire({
        title,
        text: "Revise los campos",
        icon: "error",
        confirmButtonText: "Aceptar",
        confirmButtonColor: "#4D750F"
      });
      return;
    }

    const finalAddress = [
      ub,
      vp,
      nv,
      lp,
      pfbp,
      lp2,
      cdp,
      "#",
      vs,
      nvs,
      lsec,
      pfbs,
      lsec2,
      cds,
      "-",
      vs2,
      nvs2,
      lter,
      pfbt,
      lter2,
      cdt
    ]
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();

    setFormData((prevFormData: any) => ({
      ...prevFormData,
      address: {
        value: finalAddress,
        error: false
      },
      addressComplete: {
        value: comp,
        error: false
      },
      coordenadaX: {
        value: location ? coordX : "",
        error: false
      },
      coordenadaY: {
        value: location ? coordY : "",
        error: false
      }
    }));

    onClose();
  };

  return {
    error,
    mapReady,
    customIcon,
    handleChange,
    clear,
    save
  };
}
