'use client';

import React, { useState } from 'react';

interface AnimatedTextareaProps {
    label: string;
    name: string;
    value: string;
    id?: string;
    onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
    readOnly?: boolean;
    error?: boolean;
    rows?: number;
}

export const AnimatedTextarea: React.FC<AnimatedTextareaProps> = ({
    label,
    name,
    id,
    value,
    onChange,
    readOnly = false,
    error,
    rows = 4
}) => {
    const [isFocused, setIsFocused] = useState(false);

    return (
        <div className="relative w-full">
            <textarea
                name={name}
                value={value}
                id={id}
                onChange={onChange}
                readOnly={readOnly}
                onFocus={() => setIsFocused(true)}
                onBlur={() => setIsFocused(!!value)}
                rows={rows}
                className={`
                    w-full p-3 pt-6 rounded-2xl appearance-none transition-all resize-none
                    ${error
                        ? 'bg-red-50 border border-red-500 text-red-900 placeholder-red-700 focus:ring-red-500 focus:border-red-500'
                        : 'bg-white border border-[#562707] text-[#562707]'}
                `}
                placeholder=" "
            />
            <label
                htmlFor={id}
                className={`
                    absolute left-3 top-1 px-1 text-sm bg-white transition-all pointer-events-none
                    ${isFocused || value ? '-translate-y-4 scale-90 text-[#4D750F]' : 'translate-y-2 text-gray-500'}
                    ${error ? 'text-red-700 bg-red-50' : ''}
                `}
            >
                {label}
            </label>
        </div>
    );
};
