import { useState, useEffect } from 'react';
import { fetchUserData } from '@/app/api/user/getUserData';
import { signIn } from 'next-auth/react';
import { useSession } from 'next-auth/react';

interface UseProfileImageReturn {
    imageProfile: string | null;
    isLoading: boolean;
    error: Error | null;
}

export const useProfileImage = (): UseProfileImageReturn => {
    const [imageProfile, setImageProfile] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<Error | null>(null);

    const { data: session } = useSession({
        required: true,
        onUnauthenticated() {
            signIn();
        }
    });

    const valueSesion: any = session;

    useEffect(() => {
        const getProfileImage = async () => {
            try {
                const userData = await fetchUserData(valueSesion.user.tokens.access);
                setImageProfile(userData.image_profile || null);
            } catch (err) {
                setError(err instanceof Error ? err : new Error('Error fetching profile image'));
                console.error('Error fetching profile image:', err);
            } finally {
                setIsLoading(false);
            }
        };

        getProfileImage();
    }, [session]);

    return { imageProfile, isLoading, error };
};