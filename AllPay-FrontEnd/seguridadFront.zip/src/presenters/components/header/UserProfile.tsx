'use client';

import { useEffect, useState, useRef } from 'react';

import Image from 'next/image';
import { useTheme } from 'next-themes';
import Logout from '@/presenters/components/modules/auth/Logout';
import { SessionHook } from '@/adapters/modules/auth/session-hook';
import Link from 'next/link';
import { useProfileImage } from './hooks/useProfileImage';
import LogoHome from '../ui/LogoHome';
import LogoNotificacion from '../ui/LogoNotificacion';
import LogoNoche from '../ui/logoNoche';
import LogoDia from '../ui/LogoDia';
// import LogoActivo from '../ui/LogoActivo';
import { useRouter } from 'next/navigation';

const DropdownUser = () => {
  const { theme, setTheme } = useTheme();
  const { sessionToken } = SessionHook();
  const [isLoading, setIsLoading] = useState(true);
  const [menuUser, setMenuUser] = useState(false);
  const [menuAlert, setMenuAlert] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const { imageProfile } = useProfileImage();

  const router = useRouter();

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current &&
        buttonRef.current &&
        !menuRef.current.contains(event.target as Node) &&
        !buttonRef.current.contains(event.target as Node)) {
        setMenuUser(false);
        setMenuAlert(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const dropdown = (value: string) => {
    if (value === 'user') {
      setMenuAlert(false);
      setMenuUser(!menuUser);
    } else {
      setMenuAlert(!menuAlert);
      setMenuUser(false);
    }
  };

  // const { data: session } = useSession({
  //   required: true,
  //   onUnauthenticated() {
  //     signIn();
  //   }
  // });

  // const valueSesion: any = session;

  useEffect(() => {
    if (sessionToken !== null) {
      setIsLoading(false);
    }
  }, [sessionToken]);

  if (isLoading) {
    return (
      <div className="flex flex-col gap-10">
        <p>{'Cargando...'}</p>
      </div>
    );
  }


  return (
    <div className="relative">
      <div className="flex items-center gap-4">
        <span className="text-right sm:block">
          <button
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className="flex h-12 w-12 items-center justify-center rounded-lg p-2"
          >
            {theme !== 'dark' ? <LogoNoche /> : <LogoDia />}
          </button>
        </span>

        {/* Notificaciones */}
        <span className="mt-2 text-left sm:block">
          {' '}
          <button onClick={() => dropdown('notification')}>
            <LogoNotificacion />
          </button>
        </span>
        <span className="mt-2 text-left sm:block">
          {' '}
          {/* Añade mt-2 (margin-top: 0.5rem) o el valor que necesites */}
          <button onClick={() => router.push('/home')}>
            <LogoHome />
          </button>
        </span>

        {/* Imagen del perfil del usuario */}
        <span className="text-left sm:block">
          <div className="flex items-center justify-center">
            <button
              ref={buttonRef}
              onClick={() => dropdown('user')}
              className="h-12 w-12 cursor-pointer rounded-lg p-2"
            >
              <div className="items-center">
                <img
                  className="h-8 w-12 rounded-full"
                  src={
                    imageProfile ||
                    'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=facearea&facepad=4&w=880&h=880&q=100'
                  }
                  alt="Profile"
                />
              </div>
            </button>
          </div>

          {menuUser && (
            <div
              ref={menuRef}
              className={`duration-00 absolute end-0 z-10 mt-2 w-56 transform divide-y divide-gray-100 rounded-md bg-white shadow-lg transition-all ${menuUser
                ? 'translate-y-0 opacity-100'
                : 'pointer-events-none -translate-y-2 opacity-0'
                } ${theme === 'dark' ? 'darkLi' : 'border border-gray-100'}`}
              role="menu"
            >
              <div className="p-2">
                <Link
                  href="/profile"
                  className={`block rounded-lg px-4 py-2 text-sm ${theme === 'dark' ? 'bg-opacity-10 bg-opacity-10 text-white hover:bg-[#78390e] focus:bg-[#78390e]' : 'hover:bg-gray-50'}`}
                  onClick={() => setMenuUser(false)}
                  role="menuitem"
                >
                  Mi Perfil
                </Link>


              </div>

              <div className="p-2">
                <Logout />
              </div>
            </div>
          )}
        </span>
        {/* Fin menu */}
        <span className="h-12 w-12 rounded-full">
          <Image
            width={112}
            height={112}
            src={'/images/corporate/icon.png'}
            style={{
              width: 'auto',
              height: 'auto'
            }}
            alt=""
            className="rounded-full"
          />
        </span>
      </div>
    </div>
  );
};

export default DropdownUser;
