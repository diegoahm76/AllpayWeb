'use client';

import { useTheme } from 'next-themes';
import UserProfile from './UserProfile';
import { useSession, signIn } from 'next-auth/react';

const Header = () => {
  const { theme } = useTheme();

  const { data: session } = useSession({
    required: true,
    onUnauthenticated() {
      signIn();
    }
  });
  const valueSesion: any = session;

  return (
    <header
      className={`drop-shadow-1 sticky top-0 z-40 flex w-full bg-white shadow ${theme === 'dark' ? 'dark' : ''
        }`}
    >
      <div className="shadow-2 flex flex-grow items-center justify-between px-4 py-4 md:px-4 2xl:px-8">
        <div
          className={`${theme === 'dark' ? 'text-white' : 'text-[#562707]'
            } rounded-lg p-2 hover:bg-gray-100 focus:bg-gray-100`}
          style={{
            fontSize: '14px', // Ajuste manual para tamaño personalizado
            lineHeight: '18px' // Altura de línea para mejorar la legibilidad
          }}
        >
          {session ? (
            <pre
              className="font-mono font-bold text-md sm:text-xl"
              style={{
                lineHeight: '20px'
              }}
            >
              {valueSesion.user.nombre_de_usuario}
            </pre>
          ) : (
            <p
              className="font-bold"
              style={{
                fontSize: '14px',
                lineHeight: '18px'
              }}
            >
              No hay sesión activa
            </p>
          )}
        </div>

        <div className="block sm:w-1/3" />
        <div className="2xsm:gap-5 flex items-center gap-2">
          <UserProfile />
        </div>
      </div>
    </header>
  );
};

export default Header;
