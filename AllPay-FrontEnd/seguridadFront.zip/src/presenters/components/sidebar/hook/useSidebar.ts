"use client";
import { useState, useEffect, useCallback } from "react";
import { useSession, signIn, signOut } from "next-auth/react";
import axios from "axios";
import { Exception } from "@/adapters/shared/exception";
import Swal from "sweetalert2";
import { Path } from "@/application/shared/path.enum";

export interface Permisos {
  crear: boolean;
  actualizar?: boolean;
  consultar: boolean;
  borrar?: boolean;
}

export interface Modulo {
  id_modulo: number;
  nombre_modulo: string;
  descripcion: string;
  ruta_formulario: string;
  nombre_icono: string;
  id_menu: number;
  permisos: Permisos;
}

export interface Subsistema {
  subsistema: string;
  desc_subsistema: string;
  modulos: Modulo[];
}

export interface SidebarState {
  menu: Subsistema[];
  loading: boolean;
  moduloActivo: number | null;
  setModuloActivo: (modulo: number | null) => void;
}

const baseApiUrl = process.env.BASE_API_URL;

export const useSidebar = (entorno: string): SidebarState => {
  const { data: session } = useSession({
    required: true,
    onUnauthenticated() {
      signIn();
    }
  });
  const valueSesion: any = session;
  const [loading, setLoading] = useState<boolean>(false);
  const [menu, setMenu] = useState<Subsistema[]>([]);
  const [moduloActivo, setModuloActivo] = useState<number | null>(null);

  const obtenerMenu = useCallback(async (value: string) => {
    if (value) {
      setLoading(true);
      try {
        const response = await axios.get(`${baseApiUrl}permisos/permisos-rol/get-by-entorno/?tipo_entorno=${value}`, {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${valueSesion?.user?.tokens?.access}`
          }
        }).catch((error) => error.response);
        if (response?.data?.success === false) throw response.data.detail;
        setMenu(response.data.data);

        const savedModulo = localStorage.getItem("moduloActivo");
        if (savedModulo) {
          setModuloActivo(Number(savedModulo));
        } else if (response.data.data.length > 0) {
          const primerSubsistema = response.data.data[0];
          if (primerSubsistema.modulos.length > 0) {
            const primerModulo = primerSubsistema.modulos[0];
            setModuloActivo(primerModulo.id_modulo);
            localStorage.setItem("moduloActivo", String(primerModulo.id_modulo));
          }
        }
      } catch (error) {
        if (error == "NO SE LE PERMITIRÁ TRABAJAR EN ENTORNO LABORAL, dado que la persona no está actualmente vinculada o la fecha final del cargo ha vencido") {
          await Swal.fire({
            title: 'Acceso Denegado',
            text: error as string,
            icon: 'error',
            confirmButtonColor: '#4D750F',
            confirmButtonText: 'Aceptar'
          });
          await signOut({ redirect: false, callbackUrl: Path.Login });
        }

        throw new Exception(error as string);
      } finally {
        setLoading(false);
      }
    }
  }, [valueSesion]);

  useEffect(() => {
    if (entorno) {
      obtenerMenu(entorno);
    }
  }, [obtenerMenu, entorno]);

  return { menu, loading, moduloActivo, setModuloActivo };
};
