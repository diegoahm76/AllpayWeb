'use client';

import { useState, FormEvent } from 'react';
import axios from 'axios';
import ReCAPTCHA from 'react-google-recaptcha';
import { Exception } from '@/adapters/shared/exception';
import { AuthResource } from '@/application/auth/resources/auth.resource';
import Swal from "sweetalert2";

const valid = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/

const FormRecoveryComplete = ({ capchaApiKey, baseApiUrl }: { capchaApiKey: string, baseApiUrl: string }) => {

  const urlParams = new URLSearchParams(window.location.search);
  const token = urlParams.get('token');
  const uidb64 = urlParams.get('uidb64');


  const [error, setError] = useState<string>('');
  const [message, setMessage] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  //const [messageRedirect, setMessageRedirect] = useState<string>('');
  const [formData, setFormData] = useState<any>({
    password: { value: '', error: false },
    password_confirm: { value: '', error: false },
    capcha: ''
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showPassword2, setShowPassword2] = useState(false);

  const toggleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const toggleShowPassword2 = () => {
    setShowPassword2(!showPassword2);
  };


  function redirect() {
    localStorage.clear()
    if (window.location.port) {
      window.location.replace(`${window.location.protocol}//${window.location.hostname}:${window.location.port}`)
    } else {
      window.location.replace(`${window.location.protocol}//${window.location.hostname}`);
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prevFormData: any) => ({
      ...prevFormData,
      [name]: {
        ...prevFormData[name],
        value: value,
        error: false
      }
    }));
  };


  const handleSubmitPassword = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    let error: boolean = false;
    let title: string = '';
    if (valid.test(formData.password.value) && formData.password.value.trim().length > 5) {
      if (formData.password.value !== formData.password_confirm.value) {
        error = true;
        title = 'Contraseñas no son iguales';
        setFormData((prevFormData: any) => ({
          ...prevFormData,
          ['password']: { value: formData.password.value, error: true },
          ['password_confirm']: { value: formData.password_confirm.value, error: true }
        }));
      }
      else if (formData.capcha === '') {
        error = true
        title = 'Debe validar que no es un robot';
      }
      else if (token && uidb64) {
        try {
          const payload = {
            uidb64: uidb64,
            token: token,
            password: formData.password.value
          };

          const response = await axios.patch(`${baseApiUrl}users/pasword-reset-complete`, payload, {
            headers: {
              'Content-Type': 'application/json'
            }
          });
          if (response.data.success) {
            setFormData((prevFormData: any) => ({
              ...prevFormData,
              ['password']: { value: '', error: false },
              ['password_confirm']: { value: '', error: false }
            }));

            Swal.fire({
              icon: "success",
              title: "¡Contraseña cambiada!",
              text: response.data.detail,
              confirmButtonColor: "#4D750F",
              confirmButtonText: AuthResource.Acept,
            });

            //setMessage(response.data.detail);
            setError('');
            //setMessageRedirect('Sera redirigido en unos segundos')
            setTimeout(redirect, 4000);
            setLoading(false);
          }
        } catch (error: unknown | any) {
          setMessage('');
          setFormData((prevFormData: any) => ({
            ...prevFormData,
            ['password']: { value: '', error: false },
            ['password_confirm']: { value: '', error: false }
          }));

          Swal.fire({
            icon: "error",
            title: "Oops...",
            text: error.response.data.detail,
            confirmButtonColor: "#4D750F",
            confirmButtonText: AuthResource.Acept,
          });
          
          //setError(error.response.data.detail);
          setLoading(false);
          new Exception('', error as Error);
        }
      } else {
        error = true;
        title = 'Error en token';
      }
    } else {
      error = true;
      title = 'Contraseña no cumple con los requisitos minimos'
    }
    if (error) {

      Swal.fire({
        icon: "error",
        title: "Oops...",
        text: title,
        confirmButtonColor: "#4D750F",
        confirmButtonText: AuthResource.Acept,
      });
      
      //setError(title);
      setMessage('');
      setLoading(false);
    }


  };

  const restoreCatcha = () => {
    setFormData((prevFormData: any) => ({
      ...prevFormData,
      capcha: ''
    }));
  }

  const handleCaptchaChange = (value: string | null) => {
    setTimeout(restoreCatcha, 60000);
    setFormData((prevFormData: any) => ({
      ...prevFormData,
      capcha: value
    }));
  };

  return (
    <>
      {error && <div className="flex items-center p-4 mb-4 text-sm text-white rounded-lg bg-red-600" role="alert">
        <svg className="shrink-0 inline w-4 h-4 me-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
          <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
        </svg>
        <span className="sr-only">Info</span>
        <div>
          <span className="font-medium">¡Error!</span> {error}
        </div>
      </div>}
      
      {message && <div className="flex items-center p-4 mb-4 text-sm text-white rounded-lg bg-[#4D750F]" role="alert">
        <svg className="shrink-0 inline w-4 h-4 me-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
          <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
        </svg>
        <span className="sr-only">Info</span>
        <div>
          <span className="font-medium">¡Exitoso!</span> {message}
        </div>
      </div>}

      {/* {messageRedirect && <div className="flex items-center p-4 mb-4 text-sm text-white rounded-lg bg-[#4D750F]" role="alert">
        <svg className="shrink-0 inline w-4 h-4 me-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
          <path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
        </svg>
        <span className="sr-only">Info</span>
        <div>
          <span className="font-medium"></span> {messageRedirect}
        </div>
      </div>} */}

      <form onSubmit={handleSubmitPassword}>
        <div className="mb-4">
          <label className={formData.password.error ? "block text-sm text-[#d60f30] mb-2 font-bold" : "block text-sm text-[#562707] mb-2 font-bold"} htmlFor="password">
            {AuthResource.Password}
          </label>
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              name="password"
              id="password"
              placeholder={AuthResource.Password}
              value={formData.password.value}
              onChange={handleChange}
              className={formData.password.error ? 'w-full rounded-lg bg-red-50 border border-red-500 text-red-900 placeholder-red-700 focus:ring-red-500 focus:border-red-500 p-2.5' : 'w-full rounded-lg border border-[#562707] p-2 text-[#562707]'}
            />
            <button
              type="button"
              onClick={toggleShowPassword}
              className="absolute inset-y-0 right-0 flex items-center pr-3"
            >
              {showPassword ? (
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="icon icon-tabler icons-tabler-outline icon-tabler-eye-off"><path stroke="none" d="M0 0h24v24H0z" fill="none" /><path d="M10.585 10.587a2 2 0 0 0 2.829 2.828" /><path d="M16.681 16.673a8.717 8.717 0 0 1 -4.681 1.327c-3.6 0 -6.6 -2 -9 -6c1.272 -2.12 2.712 -3.678 4.32 -4.674m2.86 -1.146a9.055 9.055 0 0 1 1.82 -.18c3.6 0 6.6 2 9 6c-.666 1.11 -1.379 2.067 -2.138 2.87" /><path d="M3 3l18 18" /></svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="icon icon-tabler icons-tabler-outline icon-tabler-eye"><path stroke="none" d="M0 0h24v24H0z" fill="none" /><path d="M10 12a2 2 0 1 0 4 0a2 2 0 0 0 -4 0" /><path d="M21 12c-2.4 4 -5.4 6 -9 6c-3.6 0 -6.6 -2 -9 -6c2.4 -4 5.4 -6 9 -6c3.6 0 6.6 2 9 6" /></svg>
              )}
            </button>
          </div>
        </div>
        <div className="mb-4">
          <label className={formData.password_confirm.error ? "block text-sm text-[#d60f30] mb-2 font-bold" : "block text-sm text-[#562707] mb-2 font-bold"} htmlFor="password_confirm">
            {AuthResource.PasswordConfirm}
          </label>
          <div className="relative">
            <input
              type={showPassword2 ? "text" : "password"}
              name="password_confirm"
              id="password_confirm"
              placeholder={AuthResource.PasswordConfirm}
              value={formData.password_confirm.value}
              onChange={handleChange}
              className={formData.password_confirm.error ? 'rounded-lg bg-red-50 border border-red-500 text-red-900 placeholder-red-700 focus:ring-red-500 dark:bg-gray-700 focus:border-red-500 block w-full p-2.5 dark:text-red-500 dark:placeholder-red-500 dark:border-red-500' : 'w-full rounded-lg border border-[#562707] p-2 text-[#562707]'}
            />
            <button
              type="button"
              onClick={toggleShowPassword2}
              className="absolute inset-y-0 right-0 flex items-center pr-3"
            >
              {showPassword2 ? (
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="icon icon-tabler icons-tabler-outline icon-tabler-eye-off"><path stroke="none" d="M0 0h24v24H0z" fill="none" /><path d="M10.585 10.587a2 2 0 0 0 2.829 2.828" /><path d="M16.681 16.673a8.717 8.717 0 0 1 -4.681 1.327c-3.6 0 -6.6 -2 -9 -6c1.272 -2.12 2.712 -3.678 4.32 -4.674m2.86 -1.146a9.055 9.055 0 0 1 1.82 -.18c3.6 0 6.6 2 9 6c-.666 1.11 -1.379 2.067 -2.138 2.87" /><path d="M3 3l18 18" /></svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="icon icon-tabler icons-tabler-outline icon-tabler-eye"><path stroke="none" d="M0 0h24v24H0z" fill="none" /><path d="M10 12a2 2 0 1 0 4 0a2 2 0 0 0 -4 0" /><path d="M21 12c-2.4 4 -5.4 6 -9 6c-3.6 0 -6.6 -2 -9 -6c2.4 -4 5.4 -6 9 -6c3.6 0 6.6 2 9 6" /></svg>
              )}
            </button>
          </div>
        </div>
        <div className="mb-4 table m-auto">
          <ReCAPTCHA
            sitekey={capchaApiKey}
            onChange={handleCaptchaChange}
          />
        </div>
        <button
          type="submit"
          className="m-auto block rounded-full shadow-xl bg-[#4D750F] px-6 py-2 font-medium text-white"
        >
          Cambiar
          {loading && (
            <span className="loader" style={{ width: '20px', height: '20px', marginLeft: '10px' }}></span>
          )}
        </button>
        <p className='text-left text-[#562707] font-bold mb-4 mt-4'>- {AuthResource.UnlockedPagePassword}</p>
        <p className='text-left text-[#562707] font-bold mb-4 mt-4'>- {AuthResource.UnlockedPagePassword2}</p>
        <p className='text-left text-[#562707] font-bold mb-4 mt-4'>- {AuthResource.UnlockedPagePassword3}</p>
        <p className='text-left text-[#562707] font-bold mb-4 mt-4'>- {AuthResource.UnlockedPagePassword4}</p>
      </form>
    </>
  );
};

export default FormRecoveryComplete;