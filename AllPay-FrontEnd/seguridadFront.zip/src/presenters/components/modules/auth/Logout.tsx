'use client';

import { signOut, useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Path } from '@/application/shared/path.enum';
import { AuthResource } from '@/application/auth/resources/auth.resource';
import Swal from "sweetalert2";

const LogoutButton = () => {
  const router = useRouter();
  const { data: session, status } = useSession();

  const handleLogout = async () => {
    try {
      const result = await Swal.fire({
        title: AuthResource.LogoutTitle,
        text: AuthResource.LogoutConfirm,
        icon: "warning",
        showCancelButton: true,
        cancelButtonColor: "#4D750F",
        confirmButtonText: AuthResource.Acept,
        confirmButtonColor: "#4D750F",
        cancelButtonText: AuthResource.Cancel,
      });

      if (!result.isConfirmed) return;

      await signOut({
        redirect: false,
        callbackUrl: Path.Login
      });

      localStorage.clear();
      sessionStorage.clear();

      setTimeout(() => {
        router.push(Path.Login);
      }, 50);

    } catch (error) {
      console.error('Logout error:', error);
      await Swal.fire({
        title: AuthResource.LogoutError,
        icon: "error",
        confirmButtonColor: "#4D750F",
        confirmButtonText: AuthResource.Acept,
      });
    }
  };

  if (status === 'unauthenticated' || !session) {
    return null;
  }

  return (
    <p onClick={handleLogout}>
      <a className="flex items-center py-2 px-2.5 bg-[#fa0a02] text-sm text-white rounded-lg" href="#">
        {AuthResource.Logout}
      </a>
    </p>
  );
};

export default LogoutButton;