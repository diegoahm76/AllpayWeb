'use client';

import { useState, FormEvent, useEffect } from 'react';
import { signIn } from 'next-auth/react';
import ReCAPTCHA from 'react-google-recaptcha';
import axios from 'axios';
import Swal from "sweetalert2";

import { Exception } from '@/adapters/shared/exception';
import { AuthResource } from '@/application/auth/resources/auth.resource';
import { Credentials } from '@/domain/auth/types/credentials.type';

import { generate2FACode } from '@/app/api/auth/createCode2fa';
import { fetchAuthenticationMethods } from '@/app/api/auth/authenticationMethods'
import { getCode2fa } from '@/app/api/auth/getCode2fa';
import { verify2FACode } from '@/app/api/auth/verifyCode2fa';
import { Button } from '@/presenters/components/ui/AnimatedButton';
import AnimatedInput from '@/presenters/components/ui/AnimatedInput'

class Autenticate {
  public static async SignIn(credentials: Credentials): Promise<boolean> {
    try {
      const params = await signIn('credentials', {
        ...credentials,
        redirect: false,
      });
      if (
        params?.error === 'AccessDenied' ||
        params?.error === 'CredentialsSignin'
      ) {
        return false;
      }
      return true;
    } catch (error) {
      new Exception('', error as Error);
      return false;
    }
  }
}

const validateUser = async (baseApiUrl: string, data: any) => {
  try {
    const response = await axios
      .post(`${baseApiUrl}users/validate/`, data, {
        headers: { 'Content-Type': 'application/json' },
      })
      .catch((error) => {
        console.log("error que no se deberia mostrar");
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: error.response,
          confirmButtonColor: 'rgb(var(--green))',
          confirmButtonText: AuthResource.Acept,
        });
        return error.response;
      });
    if (response.data.success === false) {
      return response.data;
    } else if (response.data.success === true) {
      return response.data;
    }
    return null;
  } catch (error: any) {
    if (typeof error === 'string') {

      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: error,
        confirmButtonColor: 'rgb(var(--green))',
        confirmButtonText: AuthResource.Acept,
      });
    } else {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Ha ocurrido un error contacte con el administrador',
        confirmButtonColor: 'rgb(var(--green))',
        confirmButtonText: AuthResource.Acept,
      });
    }
    return null;
  }
};

interface TwoFactorMethod {
  id_2fa_persona: number;
  tipo_2fa: string;
  nombre_tipo_2fa: string;
  descripcion_2fa: string;
  email_verificacion: string | null;
  tel_verificacion: string | null;
  id_persona: number;
  id_2fa: number;
}


export default function FormLogin({
  capchaApiKey,
  baseApiUrl,
}: {
  capchaApiKey: string;
  baseApiUrl: string;
}) {
  const [, setError] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [count, setCount] = useState<number>(0);
  const [, setMessage] = useState<string>('');
  const [formData, setFormData] = useState<any>({
    user: { value: '', error: false },
    password: { value: '', error: false },
    capcha: '',
  });

  const [resendTimer, setResendTimer] = useState<number>(120);

  const [show2FA, setShow2FA] = useState<boolean>(false);
  const [otpCode, setOtpCode] = useState<string>('');
  const [tempUser, setTempUser] = useState<string>('');
  const [tempPass, setTempPass] = useState<string>('');
  const [accessToken, setAccessToken] = useState<string>('');
  const [tfaMethod, setTfaMethod] = useState<TwoFactorMethod | null>(null);

  const [, setIdVerificacion2FA] = useState<number | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prevFormData: any) => ({
      ...prevFormData,
      [name]: { ...prevFormData[name], value, error: false },
    }));
  };


  const doValidateUser = async (username: string) => {
    const response = await validateUser(baseApiUrl, {
      nombre_de_usuario: username,
    });
    return response;
  };

  const finalSignIn = async (user: string, pass: string) => {
    const isAuthenticated = await Autenticate.SignIn({ user, password: pass });
    if (!isAuthenticated) {
      const response = await doValidateUser(user);
      if (response?.code === 101) {
        setCount(response.data.contador);
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: `${AuthResource.InvalidCredentials}: ${3 - response.data[0].contador}`,
          confirmButtonColor: 'rgb(var(--green))',
          confirmButtonText: AuthResource.Acept,
        });
        setLoading(false);
      } else if (response?.code === 102) {
        setCount(3);
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: `${AuthResource.UnlockedDescription}`,
          confirmButtonColor: 'rgb(var(--green))',
          confirmButtonText: AuthResource.Acept,
        });
        setLoading(false);
      }
      return;
    }
    window.location.href = '/';
  };

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (show2FA && resendTimer > 0) {
      timer = setTimeout(() => {
        setResendTimer(prev => prev - 1);
      }, 1000);
    }
    return () => clearTimeout(timer);
  }, [show2FA, resendTimer]);

  const handleVerify2FA = async () => {
    setLoading(true);
    try {

      const codeData = await getCode2fa(accessToken);
      const idVer = Array.isArray(codeData.data)
        ? codeData.data[0].id_verificacion_2fa
        : codeData.data.id_verificacion_2fa;
      setIdVerificacion2FA(idVer);
      const verifyResp = await verify2FACode(accessToken, otpCode, idVer);
      if (!verifyResp.success) {
        Swal.fire({
          icon: 'error',
          title: 'Código incorrecto',
          text: 'Por favor, intenta de nuevo',
        });
        setLoading(false);
        return;
      }

      await finalSignIn(tempUser, tempPass);
    } catch (err) {
      Swal.fire({
        icon: 'error',
        title: 'Error verificación 2FA',
        text: 'No se pudo verificar el código de 2FA',
        confirmButtonColor: 'rgb(var(--green))',
        confirmButtonText: AuthResource.Acept,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleResendCode = async () => {
    if (!tfaMethod) return;
    setLoading(true);
    try {
      const req2fa = await generate2FACode(accessToken, tfaMethod);
      if (!req2fa.success) {
        Swal.fire({
          icon: "error",
          title: "Error 2FA",
          text: "No se pudo generar/enviar el código de 2FA",
        });
        setLoading(false);
        return;
      }
      Swal.fire({
        icon: "success",
        title: "Código enviado",
        text: "El código se ha reenviado correctamente",
      });

      setResendTimer(120);
    } catch (error) {
      Swal.fire({
        icon: "error",
        title: "Error 2FA",
        text: "No se pudo generar/enviar el código de 2FA",
      });
    } finally {
      setLoading(false);
    }
  };


  const handleSubmit = async (e?: FormEvent) => {
    if (e) {
      e.preventDefault();
    }

    // Validar campos vacíos
    if (formData.user.value === '' || formData.password.value === '') {
      // Marcar errores en los inputs
      setFormData((prevFormData: any) => ({
        ...prevFormData,
        user: { ...prevFormData.user, error: formData.user.value === '' },
        password: { ...prevFormData.password, error: formData.password.value === '' }
      }));

      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Debe completar todos los campos',
        confirmButtonColor: 'rgb(var(--green))',
        confirmButtonText: AuthResource.Acept,
      });
      return;
    }

    // Validar captcha
    if (formData.capcha === '') {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Debe validar que no es un robot',
        confirmButtonColor: 'rgb(var(--green))',
        confirmButtonText: AuthResource.Acept,
      });
      return;
    }

    const user = formData.user.value;
    const pass = formData.password.value;
    setLoading(true);
    try {
      const resp = await axios.post(`${baseApiUrl}users/login/`, {
        nombre_de_usuario: user,
        password: pass,
      });

      if (!resp.data.success) {
        setLoading(false);
        const response = await doValidateUser(user);
        if (response?.code === 101) {
          setCount(response.data.contador);
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: `${AuthResource.InvalidCredentials}: ${3 - response.data[0].contador}`,
            confirmButtonColor: 'rgb(var(--green))',
            confirmButtonText: AuthResource.Acept,
          });
        } else if (response?.code === 102) {
          setCount(3);
          Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: `${AuthResource.UnlockedDescription}`,
            confirmButtonColor: 'rgb(var(--green))',
            confirmButtonText: AuthResource.Acept,
          });

        }
        return;
      }
      const userData = resp.data.data;

      const has2faResponse = await fetchAuthenticationMethods(userData.tokens?.access);
      const has2FA = has2faResponse !== null ? true : false;

      if (!has2FA) {
        await finalSignIn(user, pass);
        setLoading(false);
      } else {
        const token = userData.tokens?.access || '';
        setAccessToken(token);
        setTempUser(user);
        setTempPass(pass);
        try {
          setTfaMethod(has2faResponse.data[0]);
          const req2fa = await generate2FACode(token, has2faResponse.data[0]);
          if (!req2fa.success) {
            Swal.fire({
              icon: 'error',
              title: 'Error 2FA',
              text: 'No se pudo generar/enviar código de 2FA',
            });
            setLoading(false);
            return;
          }

          setShow2FA(true);
          setLoading(false);
        } catch (error) {
          Swal.fire({
            icon: 'error',
            title: 'Error 2FA',
            text: 'No se pudo generar/enviar código de 2FA',
          });
          setLoading(false);
        }
      }
    } catch (error: any) {
      const response = await doValidateUser(user);

      if (response?.code === 101) {
        setCount(response.data.contador);
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: `${AuthResource.InvalidCredentials}: ${3 - response.data[0].contador}`,
          confirmButtonColor: 'rgb(var(--green))',
          confirmButtonText: AuthResource.Acept,
        });
      } else if (response?.code === 102) {
        setCount(3);
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: `${AuthResource.UnlockedDescription}`,
          confirmButtonColor: 'rgb(var(--green))',
          confirmButtonText: AuthResource.Acept,
        });
      }

      if (error.response.status === 403) {
        Swal.fire({
          icon: 'error',
          title: 'Oops...',
          text: error.response.data.detail,
          confirmButtonColor: 'rgb(var(--green))'
        })
      }

      setLoading(false);
      new Exception('', error as Error);
    }
  };

  const validate = async (event: FormEvent) => {
    event.preventDefault();
    setLoading(true);
    setError('');
    setMessage('');
    setCount(0);
    let hasError = false;
    let title = '';

    setFormData((prevFormData: any) => ({
      ...prevFormData,
      user: { ...prevFormData.user, error: false },
      password: { ...prevFormData.password, error: false }
    }));

    if (formData.password.value === '') {
      hasError = true;
      title = 'Revise el formulario';
      setFormData((prevFormData: any) => ({
        ...prevFormData,
        password: { ...prevFormData.password, error: true }
      }));
    }
    if (formData.user.value === '') {
      hasError = true;
      title = 'Revise el formulario';
      setFormData((prevFormData: any) => ({
        ...prevFormData,
        user: { ...prevFormData.user, error: true }
      }));
    } else if (formData.capcha === '') {
      hasError = true;
      title = 'Debe validar que no es un robot';
    }

    if (hasError) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: title,
        confirmButtonColor: 'rgb(var(--green))',
        confirmButtonText: AuthResource.Acept,
      });
      setLoading(false);
    } else {
      handleSubmit();
    }
  };

  const restoreCatcha = () => {
    setFormData((prevFormData: any) => ({
      ...prevFormData,
      capcha: '',
    }));
  };

  const handleCaptchaChange = (value: string | null) => {
    setTimeout(restoreCatcha, 60000);
    setFormData((prevFormData: any) => ({
      ...prevFormData,
      capcha: value,
    }));
  };

  return (
    <>

      {count === 3 && (
        <a href="/auth/unlocked" className="text-center text-[#4D750F] mt-4 font-bold block underline">
          {AuthResource.Unlocked}
        </a>
      )}

      {!show2FA && (
        <form onSubmit={validate}>
          <div className="mb-4 mt-6">
            <AnimatedInput
              type="text"
              name="user"
              id="user"
              label={AuthResource.User}
              value={formData.user.value}
              onChange={handleChange}
              error={formData.user.error}
            />
          </div>
          <div className="mb-4">
            <AnimatedInput
              type="password"
              name="password"
              id="password"
              label={AuthResource.InputPassword}
              value={formData.password.value}
              onChange={handleChange}
              error={formData.password.error}
            />
          </div>
          <div className="mb-4 table m-auto">
            <ReCAPTCHA sitekey={capchaApiKey} onChange={handleCaptchaChange} />
          </div>

          <Button
            onClick={() => handleSubmit()}
            title="Iniciar Sesión"
            loading={loading}
            className='m-auto'
          />
        </form>
      )}

      {
        show2FA && (
          <div className="rounded-md mt-4">
            <div className="flex justify-between items-center">
              <p className="text-md mb-4 text-[#562707]">Introducir código</p>
              {resendTimer > 0 ? (
                <p className="text-md mb-4 text-[#562707]">
                  Nuevo código en: {resendTimer}
                </p>
              ) : (
                <button
                  type="button"
                  onClick={handleResendCode}
                  className="text-md mb-4 text-[#562707] underline"
                >
                  Reenviar código
                </button>
              )}
            </div>
            <AnimatedInput
              type="text"
              name="code"
              label=""
              value={otpCode}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setOtpCode(e.target.value)
              }
            />
            <div className="flex justify-center mt-6">

              <Button
                onClick={handleVerify2FA}
                title="Confirmar"
                disabled={loading}
              />

            </div>
          </div>
        )
      }

    </>
  );
}
