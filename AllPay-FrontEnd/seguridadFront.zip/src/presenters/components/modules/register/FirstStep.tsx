"use client";

import React, { useMemo } from "react";
import { Button } from "@/presenters/components/ui/AnimatedButton";
import AnimatedSelect from "@/presenters/components/ui/AnimatedSelect";
import AnimatedInput from "@/presenters/components/ui/AnimatedInput";

interface FirstStepProps {
  typePerson: { value: string; error: boolean };
  setTypePerson: (value: { value: string; error: boolean }) => void;
  dataTypePerson: any[];
  typeDocument: { value: string; error: boolean };
  setTypeDocument: (value: { value: string; error: boolean }) => void;
  dataTypeDocument: any[];
  document: { value: string; error: boolean };
  setDocument: (value: { value: string; error: boolean }) => void;
  handleSelectChange: (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => void;
  buscarPersona: () => void;
  loading: boolean;
  isExpanded: boolean;
}

const FirstStep: React.FC<FirstStepProps> = ({
  typePerson,
  dataTypePerson,
  typeDocument,
  dataTypeDocument,
  document,
  loading,
  isExpanded,
  handleSelectChange,
  buscarPersona
}) => {

  const filteredDocumentOptions = useMemo(() => {
    if (typePerson.value === "J") {
      return dataTypeDocument.filter((doc: any) => doc.cod_tipo_documento === "NT");
    } else if (typePerson.value === "N") {
      return dataTypeDocument.filter((doc: any) => doc.cod_tipo_documento !== "NT");
    } else {
      return dataTypeDocument;
    }
  }, [typePerson.value, dataTypeDocument]);

  const documentOptions = filteredDocumentOptions.map((doc: any, index: number) => ({
    key: index,
    value: doc.cod_tipo_documento,
    title: doc.nombre
  }));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    buscarPersona();
  };

  return (
    <div className="p-1">
      <div
        className={`p-6 bg-slate-200 rounded-2xl m-auto w-full shadow-lg transition-all duration-700 ease-in-out ${isExpanded ? "max-w-md lg:max-w-full " : "max-w-md"
          }`}
      >
        <form onSubmit={handleSubmit} className="bg-white py-4 sm:px-4 rounded-xl">
          <div className="m-6">
            <div
              className={`gap-4 transition-all ${isExpanded ? "flex flex-col lg:grid lg:grid-cols-3" : "flex flex-col"
                }`}
            >
              {/* Tipo de Persona */}
              <div>
                <AnimatedSelect
                  label="Tipo de persona"
                  name="tipoPersona"
                  value={typePerson.value}
                  onChange={handleSelectChange}
                  options={dataTypePerson.map((value: any, index: number) => ({
                    key: index,
                    value: value[0],
                    title: value[1]
                  }))}
                  error={typePerson.error}
                />
              </div>

              {/* Tipo de Documento */}
              <div>
                <AnimatedSelect
                  label="Tipo de documento"
                  name="tipoDocumento"
                  value={typeDocument.value}
                  onChange={handleSelectChange}
                  options={documentOptions}
                  error={typeDocument.error}
                />
              </div>

              {/* Documento */}
              <div>
                <AnimatedInput
                  type="number"
                  name="document"
                  label="Número de documento"
                  value={document.value}
                  onChange={handleSelectChange}
                />
              </div>
            </div>

            <div className={`flex items-center justify-between mt-6 text-[#562707]`}>
              {typePerson.value === "J" ? (
                <h3 className="mr-auto">NIT sin dígito de verificación</h3>
              ) : (
                <div className="flex-1" />
              )}

              <Button onClick={buscarPersona} loading={loading} title="Buscar" />
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default FirstStep;
