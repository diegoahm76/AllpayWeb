"use client";
import React from "react";
import { Button } from "@/presenters/components/ui/AnimatedButton";


interface ProfilePhotoUploadProps {
  userData: any;
  selectedFile: File | null;
  handleFileChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const ProfilePhotoUpload: React.FC<ProfilePhotoUploadProps> = ({
  userData,
  selectedFile,
  handleFileChange,
}) => {

  return (
    <div className="flex items-center space-x-4 mb-10">
      <img
        width={150}
        height={150}
        className="w-24 h-24 rounded-full dark:border-gray-700"
        src={userData.imageProfile}
        alt="Foto de perfil"
      />
      <div className="flex flex-col">

        <Button
          onClick={() => document.getElementById("fileInput")?.click()}
          title="Cargar"
        />

        <input
          id="fileInput"
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />
        {selectedFile && (
          <p className="text-md text-gray-600 dark:text-gray-400 mt-2">
            archivo seleccionado: {selectedFile.name}
          </p>
        )}
        <p className="text-md text-gray-600 dark:text-gray-400 mt-2">
          Se permiten archivos JPG, GIF o PNG. <br />
          Tamaño máximo de 800 K.
        </p>
      </div>
    </div>
  );
};

export default ProfilePhotoUpload;
