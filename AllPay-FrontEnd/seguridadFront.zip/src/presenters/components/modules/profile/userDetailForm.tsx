"use client";
import React from "react";
import AnimatedInput from "@/presenters/components/ui/AnimatedInput";

interface UserDetailsFormProps {
  userData: any;
  setUserData: (data: any) => void;
}

const UserDetailsForm: React.FC<UserDetailsFormProps> = ({ userData, setUserData }) => {
  return (
    <>
      <div className="grid md:grid-cols-2 gap-4 mt-4 text-[#562707]">
        <AnimatedInput
          label="Primer Nombre"
          name="primer_nombre"
          value={userData.primerNombre}
          onChange={(e) =>
            setUserData({ ...userData, primerNombre: e.target.value })
          }
          readOnly
        />
        <AnimatedInput
          label="Segundo Nombre"
          name="segundo_nombre"
          value={userData.segundoNombre}
          onChange={(e) =>
            setUserData({ ...userData, segundoNombre: e.target.value })
          }
          readOnly
        />
        <AnimatedInput
          label="Primer Apellido"
          name="primer_apellido"
          value={userData.primerApellido}
          onChange={(e) =>
            setUserData({ ...userData, primerApellido: e.target.value })
          }
          readOnly
        />
        <AnimatedInput
          label="Segundo Apellido"
          name="segundo_apellido"
          value={userData.segundoApellido}
          onChange={(e) =>
            setUserData({ ...userData, segundoApellido: e.target.value })
          }
          readOnly
        />
      </div>
      <div className="grid md:grid-cols-3 gap-4 mt-4 text-[#562707]">
        <AnimatedInput
          label="Número de Teléfono"
          name="telefono"
          value={userData.telefono}
          onChange={(e) =>
            setUserData({ ...userData, telefono: e.target.value })
          }
          type="number"
        />
        <AnimatedInput
          label="País"
          name="pais"
          value={userData.pais}
          onChange={(e) =>
            setUserData({ ...userData, pais: e.target.value })
          }
          readOnly
        />
        <AnimatedInput
          label="departamento"
          name="departamento"
          value={userData.departamento}
          onChange={(e) =>
            setUserData({ ...userData, departamento: e.target.value })
          }
          readOnly
        />
        <AnimatedInput
          label="Correo Electrónico"
          name="email"
          value={userData.email}
          onChange={(e) =>
            setUserData({ ...userData, email: e.target.value })
          }
        />
        <AnimatedInput
          label="Ciudad"
          name="ciudad"
          value={userData.ciudad}
          onChange={(e) =>
            setUserData({ ...userData, ciudad: e.target.value })
          }
          readOnly
        />
        <AnimatedInput
          label="Dirección"
          name="direccion_residencia"
          value={userData.direccion}
          onChange={(e) =>
            setUserData({ ...userData, direccion: e.target.value })
          }
          readOnly
        />
      </div>
    </>
  );
};

export default UserDetailsForm;
