"use client";

import { useTheme } from "next-themes";
import { useSession, signIn } from "next-auth/react";
import { useState } from "react";
import Swal from "sweetalert2";

import { fetchEditProfile } from "@/app/api/user/editProfile";

interface UseFormUserDataProps {
  userData: any;
  setUserData: (data: any) => void;
  personaType: "N" | "J" | "";
}

export function useFormUserData({ userData, setUserData, personaType }: UseFormUserDataProps) {
  const { theme } = useTheme();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const { data: session } = useSession({
    required: true,
    onUnauthenticated() {
      signIn();
    }
  });

  const valueSesion: any = session;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;

    if (file) {
      if (file.size > 800000) {
        Swal.fire({
          icon: "error",
          title: "El archivo excede los 800 KB",
          showConfirmButton: false,
          timer: 5000
        });
        return;
      }

      setSelectedFile(file);
      const previewUrl = URL.createObjectURL(file);
      setUserData((prev: any) => ({ ...prev, imageProfile: previewUrl }));
    }
  };

  const handleUpdate = async () => {
    try {
      const dataPerson = {
        [personaType === "N" ? "telefono_celular" : "telefono_empresa"]: userData.telefono,
        email: userData.email
      };

      const formData = new FormData();
      Object.keys(dataPerson).forEach((key) => {
        formData.append(key, dataPerson[key]);
      });

      if (selectedFile) {
        formData.append("image_profile", selectedFile);
      }

      await fetchEditProfile(valueSesion.user.tokens.access, formData, personaType as "N" | "J");

      Swal.fire({
        icon: "success",
        title: "Datos actualizados",
        showConfirmButton: false,
        timer: 5000
      });

      // Esperar 3 segundos antes de recargar la página
      setTimeout(() => {
        window.location.reload();
      }, 3000);
    } catch (err) {
      Swal.fire({
        icon: "error",
        title: "Error al actualizar los datos",
        showConfirmButton: false,
        timer: 5000
      });
    }
  };

  return {
    theme,
    selectedFile,
    handleFileChange,
    handleUpdate
  };
}
