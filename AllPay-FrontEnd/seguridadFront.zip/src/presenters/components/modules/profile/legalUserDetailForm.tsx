"use client";
import React from "react";
import AnimatedInput from "@/presenters/components/ui/AnimatedInput";

interface UserDetailsFormProps {
  userData: any;
  setUserData: (data: any) => void;
}



const LegalDetailsForm: React.FC<UserDetailsFormProps> = ({ userData, setUserData }) => {

  return (
    <>

      <h2 className="text-md mb-6 font-bold mt-4 text-[#562707]">Datos legales</h2>
      
      <div className="grid md:grid-cols-2 gap-4 mb-4 text-[#562707]">
        <AnimatedInput
          label="Razón social"
          name="primer_nombre"
          value={userData.razon_social}
          onChange={(e) =>
            setUserData({ ...userData, primerNombre: e.target.value })
          }
          readOnly
        />
        <AnimatedInput
          label="Nombre comercial"
          name="segundo_nombre"
          value={userData.nombre_comercial}
          onChange={(e) =>
            setUserData({ ...userData, segundoNombre: e.target.value })
          }
          readOnly
        />
      
        <AnimatedInput
          label="Naturaleza de la empresa"
          name="segundo_apellido"
          value={userData.nombre_naturaleza_empresa}
          onChange={(e) =>
            setUserData({ ...userData, segundoApellido: e.target.value })
          }
          readOnly
        />

        
        <AnimatedInput
          label="Dirección"
          name="direccion_residencia"
          value={userData.direccion_notificaciones}
          onChange={(e) =>
            setUserData({ ...userData, direccion: e.target.value })
          }
          readOnly
        />
      </div>

      <div className="grid md:grid-cols-2 gap-4 mb-10 text-[#562707]">
        <AnimatedInput
          label="Número de Teléfono"
          name="telefono"
          value={userData.telefono}
          onChange={(e) =>
            setUserData({ ...userData, telefono: e.target.value })
          }
          type="number"
        />
      
        <AnimatedInput
          label="Correo Electrónico"
          name="email"
          value={userData.email}
          onChange={(e) =>
            setUserData({ ...userData, email: e.target.value })
          }
        />

      </div>

      <h2 className="text-md mb-6 font-bold mt-4 text-[#562707]">Datos representante legal</h2>

      <div className="grid md:grid-cols-2 gap-4 mt-4 text-[#562707]">
        <AnimatedInput
          label="Primer Nombre"
          name="rep_primer_nombre"
          value={userData.representanteLegal?.primerNombre || ''}
          onChange={(e) =>
            setUserData({
              ...userData,
              representanteLegal: {
                ...userData.representanteLegal,
                primerNombre: e.target.value,
              },
            })
          }
          readOnly
        />
         <AnimatedInput
          label="Segundo Nombre"
          name="rep_segundo_nombre"
          value={userData.representanteLegal?.segundoNombre || ''}
          onChange={(e) =>
            setUserData({
              ...userData,
              representanteLegal: {
                ...userData.representanteLegal,
                segundoNombre: e.target.value,
              },
            })
          }
          readOnly
        />
        <AnimatedInput
          label="Primer Apellido"
          name="rep_primer_apellido"
          value={userData.representanteLegal?.primerApellido || ''}
          onChange={(e) =>
            setUserData({
              ...userData,
              representanteLegal: {
                ...userData.representanteLegal,
                primerApellido: e.target.value,
              },
            })
          }
          readOnly
        />
        <AnimatedInput
          label="Segundo Apellido"
          name="rep_segundo_apellido"
          value={userData.representanteLegal?.segundoApellido || ''}
          onChange={(e) =>
            setUserData({
              ...userData,
              representanteLegal: {
                ...userData.representanteLegal,
                segundoApellido: e.target.value,
              },
            })
          }
          readOnly
        />
      </div>
    
      <div className="grid md:grid-cols-3 gap-4 mt-4 text-[#562707]">
        <AnimatedInput
          label="Número de Teléfono"
          name="telefono"
          value={userData.representanteLegal?.telefono}
          onChange={(e) =>
            setUserData({ ...userData, representanteLegal: {
              ...userData.representanteLegal,
              telefono: e.target.value,
            },
           })
          }
          type="number"
          readOnly
        />
      
        <AnimatedInput
          label="Correo Electrónico"
          name="email"
          value={userData.representanteLegal?.email}
          onChange={(e) =>
            setUserData({ ...userData, representanteLegal: {
              ...userData.representanteLegal,
              email: e.target.value,
            },
           })
          }
          readOnly
        />

        <AnimatedInput
          label="Dirección"
          name="direccion_residencia"
          value={userData.representanteLegal?.direccion}
          onChange={(e) =>
            setUserData({ ...userData, representanteLegal: {
              ...userData.representanteLegal,
              direccion: e.target.value,
            },
           })
          }
          readOnly
        />
      </div>

    </>
  );
};

export default LegalDetailsForm;
