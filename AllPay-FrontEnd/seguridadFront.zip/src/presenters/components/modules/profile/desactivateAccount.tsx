'use client';

import React from 'react';
import { useDeactivateAccount } from '@/presenters/components/modules/profile/hooks/useDeactiveAccount';
import { Button } from "@/presenters/components/ui/AnimatedButton";


interface DesactivateAccountProps {
  personaId: number | null;
}

const DesactivateAccount: React.FC<DesactivateAccountProps> = ({ personaId }) => {
  const { isChecked, setIsChecked, handleDeactivateAccount } = useDeactivateAccount(personaId);

  return (
    <div
      className={` bg-slate-200 p-6 w-full rounded-xl mt-6 shadow-md`}
    >
      <div
        className={` bg-white text-[#562707] rounded-xl p-4 shadow-md`}
      >
        <h3 className="text-lg font-bold">Desactivar cuenta</h3>

        <div className="flex items-center space-x-2 mt-2">
          <input
            type="checkbox"
            className="w-4 h-4"
            checked={isChecked}
            onChange={() => setIsChecked(!isChecked)}
          />
          <label>
            Confirmar la desactivación de mi cuenta *
          </label>
        </div>

        <div className="flex justify-center">

          <Button
            onClick={handleDeactivateAccount}
            title="Desactivar cuentas"
          />

        </div>
      </div>
    </div>
  );
};

export default DesactivateAccount;
