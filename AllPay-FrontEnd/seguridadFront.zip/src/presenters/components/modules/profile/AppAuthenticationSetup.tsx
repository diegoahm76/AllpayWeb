import React from 'react';
import ModalContainer from '../../ui/ModalContainer';

interface AppAuthenticationSetupProps {
    isOpen: boolean;
    onClose: () => void;
    onBack: () => void;
}

const AppAuthenticationSetup: React.FC<AppAuthenticationSetupProps> = ({ isOpen, onClose, onBack }) => {
    return (
        isOpen && (
            <ModalContainer isOpen={isOpen} onClose={onClose}>

                <div className='p-6'>

                    <h2 className="text-xl font-bold text-[#562707] mb-4 text-center">Agregar aplicación de autenticación</h2>

                    <p className='text-[#562707] font-semibold text-left mb-2'>Aplicaciones de autenticación</p>

                    <p className="text-[#562707] text-left mb-4">
                        Con una aplicación como Google Authenticator o Microsoft Authenticator, escanea el código QR. Authy o 1Password, escanea el codigo QR.
                    </p>

                    <p className="text-[#562707] text-left mb-4">
                        se generara un código de 6 dígitos que deberás ingresar a continuación
                    </p>

                    <div className="flex justify-center">
                        <img src="/qr-example.png" alt="Código QR" className="w-32 h-32" />
                    </div>

                    <div className="bg-[#e0dcdc] p-4 rounded-md text-left text-[#562707] mb-4">
                        KHBHFHBILSNJDNJNFVJNFJKN

                        <p className="text-sm text-left text-[#562707]">
                            Si tiene problemas para utilizar el código QR, seleccione la entrada manual en su aplicación.
                        </p>
                    </div>

                    <input
                        type="text"
                        placeholder="Introduzca el código de autenticación"
                        className="w-full p-3 border rounded-2xl placeholder-[#562707] bg-white focus:outline-none"
                    />

                    <div className="mt-6 flex justify-end space-x-4">
                        <button onClick={onBack} className="px-10 py-2 text-white bg-[#4D750F]  rounded-2xl hover:bg-green-800 transition">
                            Cancelar
                        </button>

                        <button onClick={onClose} className="px-10 py-2 text-white bg-[#4D750F] rounded-2xl hover:bg-green-800 transition">
                            Continuar
                        </button>
                    </div>

                </div>

            </ModalContainer>
        )
    );
};

export default AppAuthenticationSetup;
