'use client';

import React from 'react';
import TwoFactorAuthModal from './TwoFactorAuthModal';
import { useDobleFaActivate } from '@/presenters/components/modules/profile/hooks/useDobleFaActivate';
import { Button } from "@/presenters/components/ui/AnimatedButton";

const DobleFaActivate: React.FC = () => {

  const { isModalOpen, setIsModalOpen, hasTwoFactorAuth, handleDisableTwoFactorAuth } = useDobleFaActivate();

  return (
    <div
      className={`bg-slate-200 p-6 w-full rounded-xl mt-6 shadow-md`}
    >
      <div
        className={`bg-white text-[#562707] rounded-xl px-12 py-8 shadow-md`}
      >
        <h2 className="text-xl font-bold mb-2">Autenticación doble factor</h2>
        <p>
          {hasTwoFactorAuth
            ? 'La autenticación de dos factores está activada.'
            : 'Aún no está habilitada.'}
        </p>
        <p className="mb-4">
          La autenticación de dos factores agrega una capa adicional de seguridad a su cuenta.
        </p>
        <div className="mt-6">
          <div className="flex justify-center space-x-4">

            <Button
              onClick={() => setIsModalOpen(true)}
              title={hasTwoFactorAuth
                ? 'Autenticación activada'
                : 'Habilitar autenticación'}
            />

            {hasTwoFactorAuth && (

              <Button
                onClick={handleDisableTwoFactorAuth}
                title="Desactivar doble factor"
              />

            )}
          </div>
        </div>
      </div>

      <TwoFactorAuthModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
};

export default DobleFaActivate;
