"use client";
import React from "react";
import { useFormUserData } from "@/presenters/components/modules/profile/hooks/useFormUserData";
import ProfilePhotoUpload from "@/presenters/components/modules/profile/profilePhotoUpload";
import UserDetailsForm from "@/presenters/components/modules/profile/userDetailForm";
import LegalDetailsForm from "@/presenters/components/modules/profile/legalUserDetailForm";
import { Button } from "@/presenters/components/ui/AnimatedButton";
import { useRouter } from "next/navigation";

interface FormUserDataProps {
  userData: any;
  setUserData: (data: any) => void;
  personaType: "N" | "J" | "";
  isLoading: boolean;
}

const FormUserData: React.FC<FormUserDataProps> = ({
  userData,
  setUserData,
  personaType,
  isLoading,
}) => {

  const router = useRouter();

  const { selectedFile, handleFileChange, handleUpdate } = useFormUserData({
    userData,
    setUserData,
    personaType,
  });

  return (
    <div className="bg-slate-200 p-6 w-full rounded-xl m-auto">
      <div className="bg-white rounded-xl p-6 shadow-md pt-[55px]">
        <ProfilePhotoUpload
          userData={userData}
          selectedFile={selectedFile}
          handleFileChange={handleFileChange}
        />

        {isLoading ? (
          <p className="text-center text-gray-600 dark:text-white">
            Cargando datos...
          </p>
        ) : personaType === "N" ? (
          <UserDetailsForm userData={userData} setUserData={setUserData} />
        ) : personaType === "J" ? (
          <LegalDetailsForm userData={userData} setUserData={setUserData} />
        ) : null}

        <div className="flex justify-center space-x-6 mt-10">

          <Button
            onClick={() => router.push("/profile/changePassword")}
            title="Cambiar contraseña"
          />

          <Button
            onClick={handleUpdate}
            title="Guardar cambios"
          />

        </div>
      </div>
    </div>
  );
};

export default FormUserData;
