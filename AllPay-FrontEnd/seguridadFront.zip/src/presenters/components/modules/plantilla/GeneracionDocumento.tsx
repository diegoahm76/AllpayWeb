'use client';

import React, { useState } from 'react';
import { useTheme } from 'next-themes';
import AnimatedInput from '../../ui/AnimatedInput';
import AnimatedSelect from '../../ui/AnimatedSelect';
import { Button } from '../../ui/AnimatedButton';
import DocViewer, { DocViewerRenderers } from 'react-doc-viewer';

interface GeneracionDocumentoProps {
  onSubmit?: (data: any) => void;
}

const GeneracionDocumento: React.FC<GeneracionDocumentoProps> = () => {
  const { theme } = useTheme();
  const [formData, setFormData] = useState({
    plantilla: '',
    radicado: '',
    telefono: '',
    documentoCobro: '',
    direccion: '',
    fechaImpresion: '',
    codigoBarras: '',
    titular: '',
    cedula: '',
    liquidacionLetra: '',
    interesMora: '',
    limitePago: '',
    anio: '',
    liquidacionTotal: '',
    rp: '',
    liquidar: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleCargarCampos = () => {
    console.log('Cargar campos editables');
  };

  const handleCargar = () => {
    console.log('Cargar documento');
  };

  const handleVerBorrador = () => {
    console.log('Ver borrador');
  };

  const opcionesPlantilla = [
    { key: 'plantilla1', value: 'plantilla1', title: 'Plantilla 1' },
    { key: 'plantilla2', value: 'plantilla2', title: 'Plantilla 2' }
  ];

  const opcionesRadicado = [
    { key: 'radicado1', value: 'radicado1', title: 'Radicado 1' },
    { key: 'radicado2', value: 'radicado2', title: 'Radicado 2' }
  ];
  const file =
    'http://dev.cormacarena.gov.co/media/home/BIA/Otros/Plantillas/3820716d2097e133e012.docx';

  return (
    <div className="mx-auto w-full max-w-full p-6">
      <div
        className={`rounded-xl p-6 ${theme === 'dark' ? 'bg-opacity-10 bg-[#78390e]' : 'bg-slate-200'}`}
      >
        <div className={`mb-6 rounded-xl p-6 ${theme === 'dark' ? 'dark' : 'bg-white'}`}>
          <h2
            className={`mb-6 text-center text-2xl font-bold ${theme === 'dark' ? 'text-white' : 'text-[#562707]'}`}
          >
            Generación de Documento
          </h2>

          <div className="space-y-6">
            {/* Primera fila - Selects */}
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              <AnimatedSelect
                label="Plantilla"
                name="plantilla"
                value={formData.plantilla}
                onChange={handleSelectChange}
                options={opcionesPlantilla}
              />
              <AnimatedSelect
                label="Radicado"
                name="radicado"
                value={formData.radicado}
                onChange={handleSelectChange}
                options={opcionesRadicado}
              />
            </div>

            {/* Botones superiores */}
            <div className="flex justify-end gap-4">
              <Button onClick={handleCargarCampos} title="Cargar campos editables" />

              <Button onClick={handleCargar} title="Cargar" />
            </div>
          </div>
        </div>

        <div className={`rounded-xl p-6 ${theme === 'dark' ? 'dark' : 'bg-white'}`}>
          {/* Grid de inputs */}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <AnimatedInput
              label="Teléfono"
              type="text"
              name="telefono"
              value={formData.telefono}
              onChange={handleInputChange}
            />
            <AnimatedInput
              label="Documento Cobro"
              type="text"
              name="documentoCobro"
              value={formData.documentoCobro}
              onChange={handleInputChange}
            />
            <AnimatedInput
              label="Dirección"
              type="text"
              name="direccion"
              value={formData.direccion}
              onChange={handleInputChange}
            />
            <AnimatedInput
              label="Fecha impresión"
              type="text"
              name="fechaImpresion"
              value={formData.fechaImpresion}
              onChange={handleInputChange}
            />
            <AnimatedInput
              label="Código Barras"
              type="text"
              name="codigoBarras"
              value={formData.codigoBarras}
              onChange={handleInputChange}
            />
            <AnimatedInput
              label="Titular"
              type="text"
              name="titular"
              value={formData.titular}
              onChange={handleInputChange}
            />
            <AnimatedInput
              label="Cedula"
              type="text"
              name="cedula"
              value={formData.cedula}
              onChange={handleInputChange}
            />
            <AnimatedInput
              label="Liquidación Letra"
              type="text"
              name="liquidacionLetra"
              value={formData.liquidacionLetra}
              onChange={handleInputChange}
            />
            <AnimatedInput
              label="Interés Mora"
              type="text"
              name="interesMora"
              value={formData.interesMora}
              onChange={handleInputChange}
            />
            <AnimatedInput
              label="Limite Pago"
              type="text"
              name="limitePago"
              value={formData.limitePago}
              onChange={handleInputChange}
            />
            <AnimatedInput
              label="Anio"
              type="text"
              name="anio"
              value={formData.anio}
              onChange={handleInputChange}
            />
            <AnimatedInput
              label="Liquidación total"
              type="text"
              name="liquidacionTotal"
              value={formData.liquidacionTotal}
              onChange={handleInputChange}
            />
          </div>
          {/* Renderizar DocViewer si es .docx o .doc */}

          <div
            style={{
              height: '100vh', // Altura del 100% de la pantalla
              width: '100%',
              overflow: 'auto' // Permite el desplazamiento si el contenido es mayor
            }}
          >
            <DocViewer
              pluginRenderers={DocViewerRenderers}
              documents={[{ uri: file, fileType: 'docx' }]}
              style={{
                height: '100%', // Usa toda la altura del contenedor
                width: '100%'
              }}
            />
          </div>

          {/* Botón para descargar el documento */}
          <div className="mt-6 text-center">
            <Button title="Descargar Documento" onClick={() => window.open(file, '_blank')} />
          </div>
          {/* Botón Ver Borrador */}
          <div className="flex justify-end">
            <Button onClick={handleVerBorrador} title="Ver Borrador" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default GeneracionDocumento;
