// components/DescargarPlantilla.tsx
'use client';

import React, { useState, useEffect } from 'react';
import { useTheme } from 'next-themes';
import { useSession, signIn } from 'next-auth/react';
import { Button } from '../../ui/AnimatedButton';
import DynamicTable from '../../ui/DynamicTable';
import { useRouter } from 'next/navigation';
import { useTemplateActions } from './hooks/useGetAllTemplate';
import Swal from 'sweetalert2';
import { PlantillaInfo } from './PlantillaInfo';
import ModalContainer from "@/presenters/components/ui/ModalContainer";
import { IconButton } from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';
import CargarPlantilla from './CargarPlantilla';

interface PlantillaData {
    id: number;
    nombrePlantilla: string;
    descripcion: string;
    extension: string;
    doc_plantilla: string;
}

const DescargarPlantilla: React.FC = () => {
    const router = useRouter();
    const { theme } = useTheme();

    const { data: session } = useSession({
        required: true,
        onUnauthenticated() {
            signIn();
        },
    });
    const valueSesion: any = session;
    const token = valueSesion?.user?.tokens?.access;

    const {
        templates,
        isLoading,
        isDeleting,
        error,
        handleDeleteTemplate,
        getTemplatesForExcel
    } = useTemplateActions(token);

    const [formData, setFormData] = useState({
        numeroPlantilla: '',
        extension: '',
        descripcion: '',
    });

    const [currentPage, setCurrentPage] = useState(1);
    const [filteredTemplates, setFilteredTemplates] = useState<PlantillaData[]>([]);
    const [, setShowInfo] = useState(false);
    const [selectedTemplate, setSelectedTemplate] = useState<PlantillaData | null>(null);
    const [showModal, setShowModal] = useState(false);
    const [showCreateModal, setShowCreateModal] = useState(false);

    useEffect(() => {
        if (templates && Array.isArray(templates.data)) {
            const plantillas = templates.data.map((template) => {
                const extensionMatch = template.doc_plantilla
                    .toLowerCase()
                    .match(/\.([^.?]+)(\?|$)/);
                let fileExtension = 'otro';
                if (extensionMatch && extensionMatch[1]) {
                    fileExtension = extensionMatch[1];
                }

                return {
                    id: template.id_plantilla_doc,
                    nombrePlantilla: template.nombre,
                    descripcion: template.descripcion,
                    extension: fileExtension,
                    doc_plantilla: template.doc_plantilla,
                };
            });

            console.log('Plantillas mapeadas:', plantillas);
            setFilteredTemplates(plantillas);
        } else {
            console.log('Templates no es un array:', templates);
            setFilteredTemplates([]);
        }
    }, [templates]);

    const handleLimpiar = () => {
        setFormData({
            numeroPlantilla: '',
            extension: '',
            descripcion: '',
        });
        setShowInfo(false);

        // Restaurar la lista original
        if (templates && Array.isArray(templates.data)) {
            const plantillas = templates.data.map((template) => {
                const extensionMatch = template.doc_plantilla
                    .toLowerCase()
                    .match(/\.([^.?]+)(\?|$)/);
                let fileExtension = 'otro';
                if (extensionMatch && extensionMatch[1]) {
                    fileExtension = extensionMatch[1];
                }

                return {
                    id: template.id_plantilla_doc,
                    nombrePlantilla: template.nombre,
                    descripcion: template.descripcion,
                    extension: fileExtension,
                    doc_plantilla: template.doc_plantilla,
                };
            });

            setFilteredTemplates(plantillas);
        }
    };


    const handleViewTemplate = (template: PlantillaData) => {
        setSelectedTemplate(template);
        setFormData({
            numeroPlantilla: template.nombrePlantilla,
            extension: template.extension,
            descripcion: template.descripcion,
        });
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
        setSelectedTemplate(null);
    };

    const handleDescargar = async () => {
        try {
            if (selectedTemplate && selectedTemplate.doc_plantilla) {
                // Abrir el enlace en una nueva pestaña
                window.open(selectedTemplate.doc_plantilla, '_blank');
            } else {
                throw new Error('No se encontró el enlace del archivo');
            }
        } catch (error) {
            console.error('Error al abrir la plantilla:', error);
            await Swal.fire({
                title: 'Error',
                text: 'Error al abrir la plantilla',
                icon: 'error',
                confirmButtonColor: '#4D750F',
                confirmButtonText: 'Aceptar',
            });
        }
    };

    const handleEliminar = async (row: PlantillaData) => {
        Swal.fire({
            title: '¿Estás seguro?',
            text: 'Esta acción eliminará la plantilla seleccionada.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: 'rgb(var(--green))',
            confirmButtonText: 'Si, eliminar',
            cancelButtonColor: 'rgb(var(--green))',
            cancelButtonText: 'Cancelar',
        }).then(async (result) => {
            if (result.isConfirmed) {
                await handleDeleteTemplate(row.id);
                Swal.fire({
                    title: 'Plantilla eliminada',
                    text: 'La plantilla ha sido eliminada correctamente.',
                    icon: 'success',
                    confirmButtonColor: 'rgb(var(--green))',
                    confirmButtonText: 'Aceptar',
                });
            }
        });
    };

    const handleDownloadExcel = async () => {
        try {
            const excelData = await getTemplatesForExcel();
            return excelData;
        } catch (error) {
            console.error('Error al obtener datos para Excel:', error);
            return [];
        }
    };

    const handleCreateSuccess = () => {
        setShowCreateModal(false);
        setTimeout(() => {
            window.location.reload();
        }, 3000);
    };

    const columns = [
        {
            key: 'nombrePlantilla',
            label: 'Nombre de la Plantilla',
        },
        {
            key: 'descripcion',
            label: 'Descripción',
        },
        {
            key: 'extension',
            label: 'Extensión',
            render: (value: string) => {
                // Según la extensión, mostramos un ícono u otro
                if (value.includes('pdf')) {
                    return (
                        <img
                            src="/images/icons/pdf.png"
                            alt="PDF"
                            className="h-6 w-6"
                            title="Archivo PDF"
                        />
                    );
                } else if (value.includes('doc')) {
                    return (
                        <img
                            src="/images/icons/word.png"
                            alt="Word"
                            className="h-6 w-6"
                            title="Archivo Word"
                        />
                    );
                }
                // Fallback: otro ícono
                return (
                    <img
                        src="https://i.postimg.cc/HnnrXHHJ/file.png"
                        alt="Archivo"
                        className="h-6 w-6"
                        title="Otro tipo de archivo"
                    />
                );
            },
        },
    ];

    // DEFINIR ACCIONES (columna final)
    const actions = [
        {
            label: 'Ver',
            render: (row: PlantillaData) => (
                <IconButton
                    onClick={() => handleViewTemplate(row)}
                    sx={{
                        color: theme === 'dark' ? 'white' : '#562707',
                        '&:hover': {
                            backgroundColor:
                                theme === 'dark' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(86, 39, 7, 0.1)'
                        }
                    }}
                >
                    <VisibilityIcon />
                </IconButton>
            ),
        },
        {
            label: 'Eliminar',
            render: (row: PlantillaData) => (
                <button onClick={() => handleEliminar(row)} className="p-1" title="Eliminar">
                    <img src="/images/icons/delete.png" alt="Eliminar" className="h-6 w-6" />
                </button>
            ),
        },
    ];

    return (
        <div className="w-full max-w-full mx-auto p-6">
            <div className={`rounded-xl p-6 ${theme === 'dark' ? 'bg-opacity-10 bg-[#78390e]' : 'bg-slate-200'}`}>
                <div className={`rounded-xl p-6 ${theme === 'dark' ? 'dark' : 'bg-white'}`}>
                    <div className="space-y-6">
                        {/* Sección de la tabla */}
                        <div className="mt-8">
                            <div className="flex justify-center items-center">
                                <h3 className={`text-2xl font-bold ${theme === 'dark' ? 'text-white' : 'text-[#562707]'}`}>
                                    Plantillas
                                </h3>
                            </div>

                            {/* Error si existe */}
                            {error && <p className="text-red-500 text-center mb-4">{error}</p>}

                            <DynamicTable
                                columns={columns}
                                data={filteredTemplates}
                                currentPage={currentPage}
                                totalPages={Math.ceil(filteredTemplates.length / 10)}
                                onPageChange={setCurrentPage}
                                actions={actions}
                                isLoading={isLoading || isDeleting}
                                onDownloadExcel={handleDownloadExcel}
                            />

                            {/* Botones */}
                            <div className="flex mt-6 justify-center gap-4">
                                <Button onClick={() => router.push('/')} title="Salir" />

                                <Button title="Crear" onClick={() => setShowCreateModal(true)} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal de Ver Plantilla */}
            {showModal && selectedTemplate && (
                <ModalContainer
                    isOpen={showModal}
                    onClose={handleCloseModal}
                >
                    <PlantillaInfo
                        formData={formData}
                        onLimpiar={handleLimpiar}
                        onDescargar={handleDescargar}
                        onClose={handleCloseModal}
                    />
                </ModalContainer>
            )}

            {/* Modal de Crear Plantilla */}
            {showCreateModal && (
                <ModalContainer
                    isOpen={showCreateModal}
                    onClose={() => setShowCreateModal(false)}
                >
                    <CargarPlantilla
                        onClose={() => setShowCreateModal(false)}
                        onSuccess={handleCreateSuccess}
                    />
                </ModalContainer>
            )}
        </div>
    );
};

export default DescargarPlantilla;
