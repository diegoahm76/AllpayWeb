import { useTheme } from "next-themes";
import { Button } from "@/presenters/components/ui/AnimatedButton";
import AnimatedInput from "@/presenters/components/ui/AnimatedInput";

interface PlantillaInfoProps {
    formData: {
        numeroPlantilla: string;
        extension: string;
        descripcion: string;
    };
    onLimpiar: () => void;
    onDescargar: () => void;
    onClose: () => void;
}

export const PlantillaInfo = ({ formData, onDescargar, onClose }: PlantillaInfoProps) => {
    const { theme } = useTheme();

    return (
        <div className="w-full p-6">
            <h2 className={`text-2xl text-center font-bold mb-6 ${theme === 'dark' ? 'text-white' : 'text-[#562707]'}`}>
                Información de la Plantilla
            </h2>

            {/* Inputs */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <AnimatedInput
                    label="Número de Plantilla"
                    name="numeroPlantilla"
                    value={formData.numeroPlantilla}
                    readOnly
                    type="text"
                />
                <AnimatedInput
                    label="Extensión de la Plantilla"
                    name="extension"
                    value={formData.extension}
                    readOnly
                    type="text"
                />
            </div>

            <div className="w-full mt-6">
                <AnimatedInput
                    label="Descripción"
                    name="descripcion"
                    value={formData.descripcion}
                    readOnly
                    type="text"
                />
            </div>

            {/* Botones */}
            <div className="flex justify-end gap-4 mt-6">
                <Button onClick={onDescargar} title="Ver plantilla" />
                <Button onClick={onClose} title="Cerrar" />
            </div>
        </div>
    );
}; 