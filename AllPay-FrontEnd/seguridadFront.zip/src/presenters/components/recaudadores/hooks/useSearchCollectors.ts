import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface FormData {
    tipoDocumento: string;
    documentoIdentificacion: string;
    razonSocial: string;
    departamento: string;
    municipio: string;
    fechaInicio: string;
    fechaFin: string;
}

interface UseSearchCollectorsReturn {
    formData: FormData;
    currentPage: number;
    facturas: any[];
    handleInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    handleSelectChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
    handleBuscar: () => void;
    handleConsultar: () => void;
    handleSalir: () => void;
    setCurrentPage: (page: number) => void;
}

const useSearchCollectors = (): UseSearchCollectorsReturn => {
    const router = useRouter();
    const [formData, setFormData] = useState<FormData>({
        tipoDocumento: '',
        documentoIdentificacion: '',
        razonSocial: '',
        departamento: '',
        municipio: '',
        fechaInicio: '',
        fechaFin: ''
    });

    const [currentPage, setCurrentPage] = useState(1);
    const [facturas] = useState<any[]>([]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSelectChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleBuscar = () => {
        console.log('Buscando con:', formData);
    };

    const handleConsultar = () => {
        console.log('Consultando...');
    };

    const handleSalir = () => {
        router.push('/');
    };

    return {
        formData,
        currentPage,
        facturas,
        handleInputChange,
        handleSelectChange,
        handleBuscar,
        handleConsultar,
        handleSalir,
        setCurrentPage
    };
};

export default useSearchCollectors; 