'use client';

import React from 'react';
import { useTheme } from 'next-themes';
import AnimatedInput from '@/presenters/components/ui/AnimatedInput';
import AnimatedSelect from '@/presenters/components/ui/AnimatedSelect';
import { Button } from '@/presenters/components/ui/AnimatedButton';
import DynamicTable from '@/presenters/components/ui/DynamicTable';
import { Visibility, FileDownload } from '@mui/icons-material';
import { IconButton } from '@mui/material';
import useSearchCollectors from '@/presenters/components/recaudadores/hooks/useSearchCollectors';

const SearchCollectors = () => {

    const { theme } = useTheme();

    const {
        formData,
        currentPage,
        facturas,
        handleInputChange,
        handleSelectChange,
        handleBuscar,
        handleConsultar,
        handleSalir,
        setCurrentPage
    } = useSearchCollectors();

    const columns = [
        { key: 'fechaRegistro', label: 'FECHA DE REGISTRO FACTURA' },
        { key: 'numeroFactura', label: 'N° FACTURA ÚNICA' },
        { key: 'fechaCompra', label: 'FECHA DE COMPRA' },
        { key: 'nitProveedor', label: 'NIT PROVEEDOR' },
        { key: 'nombreProveedor', label: 'NOMBRE PROVEEDOR' },
        { key: 'departamento', label: 'DEPARTAMENTO' },
        { key: 'municipio', label: 'MUNICIPIO' },
        { key: 'totalKilos', label: 'TOTAL KILOS' },
        { key: 'cuotaFomento', label: 'CUOTA DE FOMENTO (%)' }
    ];

    const actions = [
        {
            label: 'Ver',
            render: (row: any) => (
                <IconButton
                    onClick={() => console.log('Ver:', row)}
                    sx={{
                        color: theme === 'dark' ? '#fff' : '#4D750F',
                        '&:hover': {
                            backgroundColor: theme === 'dark' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(77, 117, 15, 0.1)'
                        }
                    }}
                >
                    <Visibility />
                </IconButton>
            )
        },
        {
            label: 'Descargar',
            render: (row: any) => (
                <IconButton
                    onClick={() => console.log('Descargar:', row)}
                    sx={{
                        color: theme === 'dark' ? '#fff' : '#4D750F',
                        '&:hover': {
                            backgroundColor: theme === 'dark' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(77, 117, 15, 0.1)'
                        }
                    }}
                >
                    <FileDownload />
                </IconButton>
            )
        }
    ];

    return (
        <div className="space-y-6 p-6">
            <div className={`m-auto w-full rounded-xl p-6 ${theme === 'dark' ? 'bg-opacity-10 bg-[#78390e]' : 'bg-slate-200'}`}>
                <div className="bg-white rounded-3xl shadow-md p-6">
                    <h1 className={`text-2xl font-bold text-center my-6 ${theme === 'dark' ? 'text-white' : 'text-[#562707]'}`}>
                        Consulta Facturas Únicas Nacionales Recaudares
                    </h1>

                    <div className="grid md:grid-cols-3 gap-6">
                        <AnimatedSelect
                            label="Tipo de Documento"
                            name="tipoDocumento"
                            value={formData.tipoDocumento}
                            onChange={handleSelectChange}
                            options={[
                                { key: 'cc', value: 'CC', title: 'Cédula de Ciudadanía' },
                                { key: 'ce', value: 'CE', title: 'Cédula de Extranjería' },
                                { key: 'nit', value: 'NIT', title: 'NIT' }
                            ]}
                        />
                        <AnimatedInput
                            label="Documento de Identificación"
                            name="documentoIdentificacion"
                            value={formData.documentoIdentificacion}
                            onChange={handleInputChange}
                            type="text"
                        />
                        <AnimatedInput
                            label="Razón Social"
                            name="razonSocial"
                            value={formData.razonSocial}
                            onChange={handleInputChange}
                            type="text"
                        />
                    </div>

                    <div className="grid md:grid-cols-3 gap-6 mt-6">
                        <div className="col-span-2">
                            <AnimatedInput
                                label="Departamento"
                                name="departamento"
                                value={formData.departamento}
                                onChange={handleInputChange}
                                type="text"
                            />
                        </div>

                        <AnimatedInput
                            label="Municipio"
                            name="municipio"
                            value={formData.municipio}
                            onChange={handleInputChange}
                            type="text"
                        />
                    </div>

                    <div className="grid md:grid-cols-3 gap-6 mt-6">
                        <AnimatedInput
                            label="Fecha de Inicio"
                            name="fechaInicio"
                            value={formData.fechaInicio}
                            onChange={handleInputChange}
                            type="date"
                        />
                        <div></div>
                        <AnimatedInput
                            label="Fecha de finalización"
                            name="fechaFin"
                            value={formData.fechaFin}
                            onChange={handleInputChange}
                            type="date"
                        />
                    </div>

                    <div className="flex justify-end mt-6">
                        <Button
                            title="Buscar"
                            onClick={handleBuscar}
                        />
                    </div>
                </div>

                {/* Tabla de resultados */}
                <div className="bg-white rounded-3xl mt-6 shadow-md p-6">
                    <h2 className={`text-2xl text-center font-bold my-6 ${theme === 'dark' ? 'text-white' : 'text-[#562707]'}`}>
                        Facturas Únicas Nacionales Registradas
                    </h2>

                    <DynamicTable
                        columns={columns}
                        data={facturas}
                        currentPage={currentPage}
                        totalPages={1}
                        onPageChange={setCurrentPage}
                        actions={actions}
                    />

                    <div className="flex justify-end gap-4 mt-6">
                        <Button
                            title="Consultar"
                            onClick={handleConsultar}
                        />
                        <Button
                            title="Salir"
                            onClick={handleSalir}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default SearchCollectors;
