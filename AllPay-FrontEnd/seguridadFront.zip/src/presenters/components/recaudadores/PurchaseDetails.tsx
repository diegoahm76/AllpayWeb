'use client';

import React, { useState } from 'react';
import AnimatedInput from '@/presenters/components/ui/AnimatedInput';
import { Button } from '@/presenters/components/ui/AnimatedButton';
import DynamicTable from '@/presenters/components/ui/DynamicTable';
import Image from 'next/image';
import { useTheme } from 'next-themes';

interface FormData {
    fechaCompra: string;
    fechaRegistro: string;
    nitComprador: string;
    comprador: string;
    telefono: string;
    ciudad: string;
    tipoComprador: 'procesador' | 'exportador' | 'comerciante';
    direccion: string;
    email: string;
    facturaUnica: string;
    nitProveedor: string;
    nombreProveedor: string;
    departamento: string;
    municipio: string;
}

interface DetalleCompra {
    tipoCacao: string;
    cantidadKilos: number;
    precioKilo: number;
    valorBruto: number;
    cuotaFomento: number;
    valorNeto: number;
}

const PurchaseDetails = () => {
    const { theme } = useTheme();
    const [formData, setFormData] = useState<FormData>({
        fechaCompra: '',
        fechaRegistro: '',
        nitComprador: '',
        comprador: '',
        telefono: '',
        ciudad: '',
        tipoComprador: 'procesador',
        direccion: '',
        email: '',
        facturaUnica: '210455',
        nitProveedor: '',
        nombreProveedor: '',
        departamento: '',
        municipio: ''
    });

    const [detallesCompra,] = useState<DetalleCompra[]>([]);
    const [valorTotal, setValorTotal] = useState<string>('');

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const columns = [
        { key: 'tipoCacao', label: 'TIPO DE CACAO' },
        { key: 'cantidadKilos', label: 'CANTIDAD KILOS' },
        { key: 'precioKilo', label: 'PRECIO DE KILO' },
        { key: 'valorBruto', label: 'VALOR BRUTO (KG X PRECIO DE KG)' },
        { key: 'cuotaFomento', label: 'CUOTA DE FOMENTO (3%)' },
        { key: 'valorNeto', label: 'VALOR NETO' },
        { key: 'acciones', label: 'ACCIONES' }
    ];

    return (
        <div className="p-6 space-y-6">

            <div className={`m-auto w-full rounded-xl p-6 ${theme === 'dark' ? 'bg-opacity-10 bg-[#78390e]' : 'bg-slate-200'}`}>

                <div className="bg-white rounded-3xl shadow-md p-6 mb-6">
                    {/* Encabezado con logo */}
                    <div className='flex flex-col-2 gap-6'>

                        <div className='flex items-center justify-center'>
                            <Image
                                src="/images/corporate/logo.png"
                                alt="Federación Nacional de Cacaoteros"
                                width={300}
                                height={300}
                            />
                        </div>

                        <div className=' w-full'>

                            {/* Primera sección de datos */}
                            <div className="grid grid-cols-2 gap-4 mb-4">
                                <AnimatedInput
                                    label="FECHA DE COMPRA"
                                    name="fechaCompra"
                                    value={formData.fechaCompra}
                                    onChange={handleInputChange}
                                    type="date"
                                />

                                <AnimatedInput
                                    label="FECHA DE REGISTRO"
                                    name="fechaRegistro"
                                    value={formData.fechaRegistro}
                                    onChange={handleInputChange}
                                    type="date"
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-4 mb-4">
                                <AnimatedInput
                                    label="NIT O CC COMPRADOR"
                                    name="nitComprador"
                                    value={formData.nitComprador}
                                    onChange={handleInputChange}
                                    type="text"
                                />

                                <AnimatedInput
                                    label="COMPRADOR"
                                    name="comprador"
                                    value={formData.comprador}
                                    onChange={handleInputChange}
                                    type="text"
                                />

                            </div>

                            <div className="grid grid-cols-2 gap-4 mb-4">

                                <AnimatedInput
                                    label="TELÉFONO"
                                    name="telefono"
                                    value={formData.telefono}
                                    onChange={handleInputChange}
                                    type="text"
                                />

                                <AnimatedInput
                                    label="CIUDAD"
                                    name="ciudad"
                                    value={formData.ciudad}
                                    onChange={handleInputChange}
                                    type="text"
                                />
                            </div>

                            {/* Tipo de comprador */}
                            <div className="flex justify-between gap-6 mb-6 font-bold">
                                <div className='text-[rgb(var(--brown))]'>
                                    TIPO DE COMPRADOR
                                </div>

                                <label className="flex items-center gap-2">
                                    <input
                                        type="radio"
                                        name="tipoComprador"
                                        value="procesador"
                                        checked={formData.tipoComprador === 'procesador'}
                                        onChange={(e) => setFormData(prev => ({ ...prev, tipoComprador: e.target.value as 'procesador' }))}
                                        className="form-radio text-[#4D750F]"
                                    />
                                    <span className="text-[#562707]">PROCESADOR</span>
                                </label>
                                <label className="flex items-center gap-2">
                                    <input
                                        type="radio"
                                        name="tipoComprador"
                                        value="exportador"
                                        checked={formData.tipoComprador === 'exportador'}
                                        onChange={(e) => setFormData(prev => ({ ...prev, tipoComprador: e.target.value as 'exportador' }))}
                                        className="form-radio text-[#4D750F]"
                                    />
                                    <span className="text-[#562707]">EXPORTADOR</span>
                                </label>
                                <label className="flex items-center gap-2">
                                    <input
                                        type="radio"
                                        name="tipoComprador"
                                        value="comerciante"
                                        checked={formData.tipoComprador === 'comerciante'}
                                        onChange={(e) => setFormData(prev => ({ ...prev, tipoComprador: e.target.value as 'comerciante' }))}
                                        className="form-radio text-[#4D750F]"
                                    />
                                    <span className="text-[#562707]">COMERCIANTE</span>
                                </label>
                            </div>


                            {/* Columna de Dirección y Email */}
                            <div className="flex justify-between gap-4">
                                <div className="flex-grow space-y-4">
                                    <div className="flex items-center gap-4">

                                        <AnimatedInput
                                            label="DIRECCION    "
                                            name="direccion"
                                            value={formData.direccion}
                                            onChange={handleInputChange}
                                            type="text"
                                        />
                                    </div>
                                    <div className="flex items-center gap-4">
                                        <AnimatedInput
                                            label="E-MAIL"
                                            name="email"
                                            value={formData.email}
                                            onChange={handleInputChange}
                                            type="email"
                                        />
                                    </div>
                                </div>
                                <div className="flex flex-col items-center min-w-[200px]">
                                    <div className="text-center mb-4">
                                        <p className="text-sm font-bold text-[#562707]">FACTURA ÚNICA</p>
                                        <p className="text-sm font-bold text-[#562707]">NACIONAL</p>
                                    </div>
                                    <div className="border-2 border-[#562707] rounded px-4 py-2">
                                        <p className="text-2xl font-bold text-[#562707]">{formData.facturaUnica}</p>
                                    </div>
                                </div>
                            </div>



                        </div>

                    </div>



                </div>

                {/* Datos del proveedor */}
                <div className="bg-white p-6 rounded-3xl mb-6 ">
                    <div className="grid grid-cols-2 gap-6 mb-6 col-span-2">
                        <AnimatedInput
                            label="NIT PROVEEDOR"
                            name="nitProveedor"
                            value={formData.nitProveedor}
                            onChange={handleInputChange}
                            type="text"
                        />
                        <AnimatedInput
                            label="NOMBRE PROVEEDOR"
                            name="nombreProveedor"
                            value={formData.nombreProveedor}
                            onChange={handleInputChange}
                            type="text"
                        />
                    </div>
                    <div className="grid grid-cols-2 gap-6">
                        <AnimatedInput
                            label="DEPARTAMENTO"
                            name="departamento"
                            value={formData.departamento}
                            onChange={handleInputChange}
                            type="text"
                        />
                        <AnimatedInput
                            label="MUNICIPIO"
                            name="municipio"
                            value={formData.municipio}
                            onChange={handleInputChange}
                            type="text"
                        />
                    </div>
                </div>

                <div className="bg-white p-6 rounded-3xl mb-6 ">
                    {/* Tabla de detalles */}
                    <div className="mb-6">
                        <h2 className="text-2xl mt-[39px] text-center font-bold text-[#562707] mb-4">DETALLE DE COMPRA</h2>
                        <DynamicTable
                            columns={columns}
                            data={detallesCompra}
                            currentPage={1}
                            totalPages={1}
                            onPageChange={() => { }}
                        />
                    </div>

                    {/* Valor a pagar */}
                    <div className="flex justify-between items-center">
                        <div className="w-64">
                            <AnimatedInput
                                label="VALOR A PAGAR"
                                name="valorTotal"
                                value={valorTotal}
                                onChange={(e) => setValorTotal(e.target.value)}
                                type="text"
                            />
                        </div>
                        <Button
                            title="Salir"
                            onClick={() => console.log('Salir')}
                        />
                    </div>
                </div>




            </div>

        </div>
    );
};

export default PurchaseDetails;
