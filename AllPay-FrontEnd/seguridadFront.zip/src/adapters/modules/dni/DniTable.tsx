'use client';

import React, { useEffect, useState } from 'react';
import { useSession, signIn } from 'next-auth/react';
import { useTheme } from 'next-themes';
import DynamicTable from '@/presenters/components/ui/DynamicTable';
import { getAllDni } from '@/app/api/dni/getAllDni';
import { deleteDni } from '@/app/api/dni/deleteDni';
import { updateDni } from '@/app/api/dni/updateDni';
import ModalContainer from '@/presenters/components/ui/ModalContainer';
import AnimatedInput from '@/presenters/components/ui/AnimatedInput';
import CreateDniModal from './CreateDniModal';
import Swal from 'sweetalert2';
import { Button } from '@/presenters/components/ui/AnimatedButton';
import { useRouter } from 'next/navigation';


interface TipoDocumento {
    cod_tipo_documento: string;
    nombre: string;
}

interface FormData {
    cod_tipo_documento: string;
    nombre: string;
    activo: boolean;
}

const DniTable: React.FC = () => {
    const router = useRouter();
    const { theme } = useTheme();
    const [isLoading, setIsLoading] = useState(false);
    const [dniData, setDniData] = useState<TipoDocumento[]>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [showModal, setShowModal] = useState(false);
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [selectedDni, setSelectedDni] = useState<TipoDocumento | null>(null);
    const [formData, setFormData] = useState<FormData>({
        cod_tipo_documento: '',
        nombre: '',
        activo: true
    });

    const { data: session } = useSession({
        required: true,
        onUnauthenticated() {
            signIn();
        }
    });

    const valueSesion: any = session;

    const fetchDniData = async () => {
        try {
            setIsLoading(true);
            const response = await getAllDni(valueSesion?.user?.tokens?.access);
            setDniData(response.data);
            setTotalPages(1);
        } catch (error: any) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: error.message || 'Error al obtener los tipos de documento'
            });
        } finally {
            setIsLoading(false);
        }
    };

    const handleDelete = async (row: TipoDocumento) => {
        try {
            const result = await Swal.fire({
                title: '¿Estás seguro?',
                text: `¿Deseas eliminar el tipo de documento "${row.nombre}"?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#4D750F',
                cancelButtonColor: '#4D750F',
                confirmButtonText: 'Sí, eliminar',
                cancelButtonText: 'Cancelar'
            });

            if (result.isConfirmed) {
                await deleteDni(valueSesion?.user?.tokens?.access, row.cod_tipo_documento);

                Swal.fire({
                    icon: 'success',
                    title: 'Eliminado',
                    text: 'El tipo de documento ha sido eliminado correctamente',
                    confirmButtonColor: '#4D750F'
                });

                fetchDniData();
            }
        } catch (error: any) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: error.message || 'Error al eliminar el tipo de documento',
                confirmButtonColor: '#4D750F'
            });
        }
    };

    const handleEdit = (row: TipoDocumento) => {
        setSelectedDni(row);
        setFormData({
            cod_tipo_documento: row.cod_tipo_documento,
            nombre: row.nombre,
            activo: true
        });
        setShowModal(true);
    };

    const handleUpdate = async () => {
        try {
            if (!selectedDni) return;

            await updateDni(
                valueSesion?.user?.tokens?.access,
                selectedDni.cod_tipo_documento,
                {
                    nombre: formData.nombre,
                    activo: formData.activo
                }
            );

            Swal.fire({
                icon: 'success',
                title: 'Actualizado',
                text: 'El tipo de documento ha sido actualizado correctamente',
                confirmButtonColor: '#4D750F'
            });

            setShowModal(false);
            fetchDniData();
        } catch (error: any) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: error.message || 'Error al actualizar el tipo de documento',
                confirmButtonColor: '#4D750F'
            });
        }
    };

    const handleDownloadExcel = async () => {
        try {
            const response = await getAllDni(valueSesion?.user?.tokens?.access);
            const data = response.data;

            if (!data || data.length === 0) {
                return [];
            }

            return data.map((item: TipoDocumento) => ({
                'Código': item.cod_tipo_documento,
                'Nombre': item.nombre
            }));
        } catch (error) {
            console.error('Error al obtener datos para Excel:', error);
            return [];
        }
    };

    useEffect(() => {
        if (valueSesion?.user?.tokens?.access) {
            fetchDniData();
        }
    }, [valueSesion]);

    const columns = [
        {
            key: 'cod_tipo_documento',
            label: 'Código'
        },
        {
            key: 'nombre',
            label: 'Nombre'
        }
    ];

    const actions = [
        {
            label: 'Editar',
            render: (row: TipoDocumento) => (
                <button
                    onClick={() => handleEdit(row)}
                >
                    <img
                        src="https://i.postimg.cc/hPVKjZ05/Grupo-1126.png"
                        alt="Editar"
                        className="h-6 w-6"
                    />
                </button>
            )
        },
        {
            label: 'Eliminar',
            render: (row: TipoDocumento) => (
                <button
                    onClick={() => handleDelete(row)}
                >
                    <img
                        src="https://i.postimg.cc/nh3rCVxb/cancel-33dp-EA3323-FILL0-wght400-GRAD0-opsz40.png"
                        alt="Eliminar"
                        className="h-6 w-6"
                    />
                </button>
            )
        }
    ];

    return (
        <div className="w-full">
            <div className="flex w-full items-center justify-center md:w-4/4 lg:w-2/2">
                <div className="w-full p-1">
                    <div className={`m-auto w-full rounded-xl p-6 ${theme === 'dark' ? 'bg-opacity-10 bg-[#78390e]' : 'bg-slate-200'}`}>
                        <div className={`rounded-xl p-4 ${theme === 'dark' ? 'dark' : 'bg-white'}`}>

                            <div className="relative flex justify-center items-center mt-[39px] ">
                                <h3
                                    className={`text-center text-3xl font-bold ${theme === 'dark' ? 'text-white' : 'text-[#562707]'
                                        }`}
                                >
                                    Tipos de Documento
                                </h3>


                            </div>

                            <DynamicTable
                                columns={columns}
                                data={dniData}
                                currentPage={currentPage}
                                totalPages={totalPages}
                                onPageChange={setCurrentPage}
                                actions={actions}
                                isLoading={isLoading}
                                onDownloadExcel={handleDownloadExcel}
                            />

                            <div className="flex justify-center mt-6 space-x-4">
                                <Button onClick={() => router.push('/')} title="Salir" />

                                <Button onClick={() => setShowCreateModal(true)} title="Crear" />
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <ModalContainer
                isOpen={showModal}
                onClose={() => setShowModal(false)}
            >
                <div className="space-y-4">
                    <h3 className={`mb-4 text-center text-xl font-bold ${theme === 'dark' ? 'text-white' : 'text-[#562707]'}`}>
                        Editar Tipo de Documento
                    </h3>
                    <AnimatedInput
                        label="Código"
                        type="text"
                        name="cod_tipo_documento"
                        value={formData.cod_tipo_documento}
                        onChange={(e) => setFormData({ ...formData, cod_tipo_documento: e.target.value })}
                        readOnly
                    />
                    <AnimatedInput
                        label="Nombre"
                        type="text"
                        name="nombre"
                        value={formData.nombre}
                        onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                    />
                    <div className="flex justify-end space-x-4 mt-6">

                        <Button onClick={() => setShowModal(false)} title="Cancelar" />

                        <Button onClick={handleUpdate} title="Guardar" />

                    </div>
                </div>
            </ModalContainer>

            <CreateDniModal
                isOpen={showCreateModal}
                onClose={() => setShowCreateModal(false)}
                onSuccess={fetchDniData}
            />
        </div>
    );
};

export default DniTable; 