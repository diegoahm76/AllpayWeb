import { useState, useEffect } from 'react';
import { useSession, signIn } from 'next-auth/react';

import { Exception, handleException } from '@/adapters/shared/exception';
import { AuthUseCase } from '@/application/auth/auth.usecase';
import { AuthResource } from '@/application/auth/resources/auth.resource';
import { UserToken } from '@/domain/auth/types/user-token.type';

import { ISessionHook } from './interface/session-hook.interface';

export const SessionHook = (): ISessionHook => {
  const {
    data: session,
    status,
    update
  } = useSession({
    required: true,
    onUnauthenticated() {
      signIn();
    }
  });

  const [sessionToken, setSessionToken] = useState<UserToken | null>(null);
  const authUseCase = new AuthUseCase();

  useEffect(() => {
    const fetchSessionToken = async () => {
      try {
        if (status === 'authenticated' && session?.user) {
          setSessionToken(session.user);
        }
      } catch (error) {
        throw handleException(error as Exception);
      }
    };

    fetchSessionToken();
  }, [session, status]);

  const Update = async (data: UserToken): Promise<void> => {
    try {
      if (!authUseCase.IsValidEmail(data.email)) {
        await alert(AuthResource.EmailValid);
        return;
      }

      await update(data);
    } catch (error) {
      throw handleException(error as Exception);
    }
  };

  return { sessionToken, Update };
};
