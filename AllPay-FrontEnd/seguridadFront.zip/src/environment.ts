export const {
  NODE_ENV,
  BASE_API_URL,
  AUTH_SECRET,
  CAPCHA_API,
  CAPCHA_API_SECRET
} = process.env;