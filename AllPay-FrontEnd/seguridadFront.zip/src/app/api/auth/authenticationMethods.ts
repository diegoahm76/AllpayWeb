import axios from 'axios';

const baseApiUrl = process.env.BASE_API_URL;

export const fetchAuthenticationMethods = async (token: string) => {


    try {
        const response = await axios.get(`${baseApiUrl}users/segundo-facto-autenticacion/usuario/get/`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json',
            },
        });

        return response.data;
    } catch (error) {
        return null;
    }
};
