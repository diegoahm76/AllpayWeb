import '@/presenters/css/globals.css';

import React from 'react';
import { auth } from '@/auth';
import { SessionProvider } from './providers/SessionProvider';

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const session = await auth();
  return (
    <html lang="es">
      <head>
        <link rel="icon" href="/icon.png" />
      </head>
      <body suppressHydrationWarning={true}>
        <div>
          <SessionProvider session={session}>
            {children}
          </SessionProvider>
        </div>
      </body>
    </html>
  );
}



