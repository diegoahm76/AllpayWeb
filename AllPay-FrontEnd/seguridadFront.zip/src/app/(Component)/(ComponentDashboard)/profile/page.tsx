'use client';

import { useEffect, useState, useCallback } from 'react';
import { useSession, signIn } from 'next-auth/react';
import Swal from 'sweetalert2';

import FormUserData from '@/presenters/components/modules/profile/formUserData';
import DesactivateAccount from '@/presenters/components/modules/profile/desactivateAccount';
import { fetchUserData } from '@/app/api/user/getUserData';

const ProfileView = () => {
  const [isLoading, setIsLoading] = useState(true);
  const { data: session } = useSession({
    required: true,
    onUnauthenticated() {
      signIn();
    }
  });

  const valueSesion: any = session;

  const [personaType, setPersonaType] = useState<'N' | 'J' | ''>('');
  const [personaId, setPersonaId] = useState<number | null>(null);
  const [userData, setUserData] = useState({
    primerNombre: '',
    segundoNombre: '',
    primerApellido: '',
    segundoApellido: '',
    telefono: '',
    pais: '',
    departamento: '',
    email: '',
    ciudad: '',
    direccion: '',
    direccion_notificaciones: '',
    imageProfile: '/images/user.jpg',
    razon_social: '',
    nombre_comercial: '',
    nombre_naturaleza_empresa: '',
    representanteLegal: {
      primerNombre: '',
      segundoNombre: '',
      primerApellido: '',
      segundoApellido: '',
      telefono: '',
      email: '',
      pais: '',
      departamento: '',
      ciudad: '',
      direccion: '',
    }
  });

  const loadUserData = useCallback(async () => {
    if (!valueSesion?.user?.tokens?.access) return;

    try {
      const userProfile = await fetchUserData(valueSesion.user.tokens.access);

      const p = userProfile.persona || {};
      setPersonaType(p.tipo_persona || '');
      setPersonaId(p.id_persona !== undefined ? p.id_persona : null);

      const rep = p.representante_legal_data || {};

      setUserData({
        primerNombre: p.primer_nombre || '',
        segundoNombre: p.segundo_nombre || '',
        primerApellido: p.primer_apellido || '',
        segundoApellido: p.segundo_apellido || '',
        telefono: p.tipo_persona === 'N' ? p.telefono_celular || '' : p.telefono_empresa || '',
        pais: p.nombre_pais || '',
        departamento: p.nombre_departamento_residencia || '',
        email: p.email || '',
        ciudad: p.nombre_municipio_residencia || '',
        direccion: p.direccion_residencia || '',
        direccion_notificaciones: p.direccion_notificaciones || '',
        imageProfile: userProfile.image_profile || '/images/user.jpg',
        razon_social: p.razon_social || '',
        nombre_comercial: p.nombre_comercial || '',
        nombre_naturaleza_empresa: p.nombre_naturaleza_empresa || '',
        representanteLegal: {
          primerNombre: rep.primer_nombre || '',
          segundoNombre: rep.segundo_nombre || '',
          primerApellido: rep.primer_apellido || '',
          segundoApellido: rep.segundo_apellido || '',
          telefono: rep.telefono_celular || '',
          email: rep.email || '',
          pais: rep.nombre_pais || '',
          departamento: rep.nombre_departamento_residencia || '',
          ciudad: rep.nombre_municipio_residencia || '',
          direccion: rep.direccion_residencia || '',
        }
      });

    } catch (error: any) {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: error.message,
        showConfirmButton: false,
        timer: 5000
      });
    } finally {
      setIsLoading(false);
    }
  }, [valueSesion]);

  useEffect(() => {
    if (valueSesion?.user?.id) {
      loadUserData();
    }
  }, [loadUserData, valueSesion?.user?.id]);

  return (
    <div className="w-full">
      <div className="w-full md:w-4/4 lg:w-2/2 flex justify-center items-center">
        <div className="p-1 w-full">
          <FormUserData
            userData={userData}
            setUserData={setUserData}
            personaType={personaType}
            isLoading={isLoading}
          />
          <DesactivateAccount personaId={personaId} />
        </div>
      </div>
    </div>
  );
};

export default ProfileView;
