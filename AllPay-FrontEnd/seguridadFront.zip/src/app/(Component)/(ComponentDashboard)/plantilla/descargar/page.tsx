'use client';

import DescargarPlantilla from '@/presenters/components/modules/plantilla/DescargarPlantilla';

export default function Page() {
    return <DescargarPlantilla />;
}
