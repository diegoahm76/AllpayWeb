'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import AnimatedInput from '@/presenters/components/ui/AnimatedInput';
import { Button } from '@/presenters/components/ui/AnimatedButton';
import AnimatedSelect from '@/presenters/components/ui/AnimatedSelect';
import { useTheme } from 'next-themes';
import { useTypesCocoa } from '../hooks/useTypesCocoa';
import { signIn, useSession } from 'next-auth/react';

interface FormData {
    tipoCacao: string;
    cantidadKilos: string;
    precioKilo: string;
    valorBruto: string;
    cuotaFomento: string;
    valorNeto: string;
}

const RegisterPurchase = () => {
    const { theme } = useTheme();
    const router = useRouter();

    const { data: session } = useSession({
        required: true,
        onUnauthenticated() {
            signIn();
        }
    });

    const valueSesion: any = session;

    const { tiposCacao, loading, error } = useTypesCocoa(valueSesion?.user?.tokens?.access || '');

    const [formData, setFormData] = useState<FormData>({
        tipoCacao: '',
        cantidadKilos: '',
        precioKilo: '',
        valorBruto: '',
        cuotaFomento: '',
        valorNeto: ''
    });

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSelectChange = (value: unknown) => {
        setFormData(prev => ({
            ...prev,
            tipoCacao: String(value)
        }));
    };

    // Calcular valores automáticamente cuando cambien los inputs
    useEffect(() => {
        if (formData.cantidadKilos && formData.precioKilo) {
            const cantidadKilos = parseFloat(formData.cantidadKilos);
            const precioKilo = parseFloat(formData.precioKilo);

            if (!isNaN(cantidadKilos) && !isNaN(precioKilo)) {
                const valorBruto = cantidadKilos * precioKilo;
                const cuotaFomento = valorBruto * 0.03; // 3% de cuota de fomento
                const valorNeto = valorBruto - cuotaFomento;

                setFormData(prev => ({
                    ...prev,
                    valorBruto: valorBruto.toFixed(2),
                    cuotaFomento: cuotaFomento.toFixed(2),
                    valorNeto: valorNeto.toFixed(2)
                }));
            }
        }
    }, [formData.cantidadKilos, formData.precioKilo]);

    const handleGuardar = () => {
        console.log('Guardando datos:', formData);
        // Aquí iría la lógica para guardar los datos
    };

    const handleLimpiar = () => {
        setFormData({
            tipoCacao: '',
            cantidadKilos: '',
            precioKilo: '',
            valorBruto: '',
            cuotaFomento: '',
            valorNeto: ''
        });
    };

    const handleSalir = () => {
        router.push('/');
    };

    return (
        <div className="flex items-center justify-center min-h-[80vh]">
            <div className={`m-auto w-full rounded-xl p-6 max-w-xl  ${theme === 'dark' ? 'bg-opacity-10 bg-[#78390e]' : 'bg-slate-200'}`}>
                <div className="bg-white rounded-xl shadow-lg p-4">
                    <h2 className="text-[#562707] text-2xl font-bold text-center mb-8 mt-[39px]">REGISTRAR OTRA COMPRA</h2>

                    <div className="space-y-6">
                        <div className="flex flex-col gap-6">
                            <div className="flex items-center gap-4">
                                <div className="flex-1">
                                    <AnimatedSelect
                                        label="TIPO DE CACAO"
                                        name="tipoCacao"
                                        value={formData.tipoCacao}
                                        onChange={handleSelectChange}
                                        options={tiposCacao}
                                    />
                                    {loading && <p className="text-gray-500 text-sm mt-1">Cargando tipos de cacao...</p>}
                                    {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
                                </div>
                            </div>

                            <div className="flex items-center gap-4">
                                <div className="flex-1">
                                    <AnimatedInput
                                        label="CANTIDAD KILOS"
                                        name="cantidadKilos"
                                        value={formData.cantidadKilos}
                                        onChange={handleInputChange}
                                        type="number"
                                    />
                                </div>
                            </div>

                            <div className="flex items-center gap-4">
                                <div className="flex-1">
                                    <AnimatedInput
                                        label="PRECIO KILO"
                                        name="precioKilo"
                                        value={formData.precioKilo}
                                        onChange={handleInputChange}
                                        type="number"
                                    />
                                </div>
                            </div>

                            <div className="flex items-center gap-4">
                                <div className="flex-1">
                                    <AnimatedInput
                                        label="VALOR DE BRUTO"
                                        name="valorBruto"
                                        value={formData.valorBruto}
                                        onChange={handleInputChange}
                                        type="number"
                                        disabled
                                    />
                                </div>
                            </div>

                            <div className="flex items-center gap-4">
                                <div className="flex-1">
                                    <AnimatedInput
                                        label="CUOTA DE FOMENTO"
                                        name="cuotaFomento"
                                        value={formData.cuotaFomento}
                                        onChange={handleInputChange}
                                        type="number"
                                        disabled
                                    />
                                </div>
                            </div>

                            <div className="flex items-center gap-4">
                                <div className="flex-1">
                                    <AnimatedInput
                                        label="VALOR NETO"
                                        name="valorNeto"
                                        value={formData.valorNeto}
                                        onChange={handleInputChange}
                                        type="number"
                                        disabled
                                    />
                                </div>
                            </div>
                        </div>

                        <div className="flex justify-center mt-8 gap-4">
                            <Button
                                title="Guardar"
                                onClick={handleGuardar}
                            />
                            <Button
                                title="Limpiar"
                                onClick={handleLimpiar}
                            />
                            <Button
                                title="Salir"
                                onClick={handleSalir}
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RegisterPurchase;
