interface TipoCacao {
    id_tipo_cacao: number;
    nombre: string;
    activo: boolean;
    item_ya_usado: boolean;
    fecha_creacion: string;
    id_persona_crea: number;
}

interface TiposCacaoResponse {
    success: boolean;
    detail: string;
    data: TipoCacao[];
}

const BASE_URL = 'http://18.231.214.12';

export const getTiposCacao = async (token: string): Promise<TiposCacaoResponse> => {
    try {
        const response = await fetch(`${BASE_URL}/api/recaudos/tipos-cacao/`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
        });

        if (!response.ok) {
            throw new Error(`Error en la petición: ${response.status}`);
        }

        const data: TiposCacaoResponse = await response.json();
        return data;

    } catch (error) {
        console.error('Error al obtener tipos de cacao:', error);
        throw error;
    }
};

export const getTiposCacaoActivos = async (token: string): Promise<TipoCacao[]> => {
    console.log("token", token)
    const response = await getTiposCacao(token);
    return response.data.filter(tipo => tipo.activo);
};

export const formatTiposCacaoForSelect = (tipos: TipoCacao[]) => {
    return tipos.map(tipo => ({
        key: tipo.id_tipo_cacao,
        value: tipo.id_tipo_cacao.toString(),
        title: tipo.nombre
    }));
};

export type { TipoCacao, TiposCacaoResponse };
