'use client';

import React from 'react';
import RegisterPurcharse from '@/app/(Component)/(ComponentDashboard)/recaudadores/registrar_compra/components/RegisterPurchase';

const DetalleCompra = () => {

    return (
        <div className="w-full">
            <RegisterPurcharse />
        </div>
    );
};

export default DetalleCompra;
