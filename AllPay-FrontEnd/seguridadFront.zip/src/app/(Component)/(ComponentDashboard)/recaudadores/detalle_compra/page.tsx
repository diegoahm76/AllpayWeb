'use client';

import React from 'react';
import PurchaseDetails from '@/presenters/components/recaudadores/PurchaseDetails';

const DetalleCompra = () => {

    return (
        <div className="w-full">
            <PurchaseDetails />
        </div>
    );
};

export default DetalleCompra;
