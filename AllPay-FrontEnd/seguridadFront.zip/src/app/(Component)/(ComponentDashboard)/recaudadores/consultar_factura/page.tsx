'use client';

import React from 'react';
import SearchCollectors from '@/presenters/components/recaudadores/CheckInvoices';

const ConsultaFacturas = () => {

    return (
        <div className="w-full">
            <SearchCollectors />
        </div>
    );
};

export default ConsultaFacturas;
