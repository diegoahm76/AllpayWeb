'use client'


const Dashboard = () => {
  return (
   <h2></h2>
  )
}

export default Dashboard;