"use client";

import React, { useState, useEffect } from "react";
import { ThemeProvider } from "next-themes";
import Sidebar from "@/presenters/components/sidebar";
import Header from "@/presenters/components/header";
import "@/presenters/css/background.css";

export default function DefaultLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [entorno, setEntorno] = useState("");

  useEffect(() => {
    let valueEntorno = localStorage.getItem("entorno");
    if (!valueEntorno) {
      localStorage.setItem("entorno", "L");
      setEntorno("L");
    } else {
      setEntorno(valueEntorno);
    }
  }, []);

  return (
    <ThemeProvider attribute="class" defaultTheme="false" enableSystem={false}>
      <div className="flex h-screen overflow-hidden">
        <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} entorno={entorno} />

        <div className="relative flex flex-1 flex-col overflow-y-auto overflow-x-hidden transition-all duration-300">
          <Header />

          <main>
            <div className="background2">
              <div className="mx-auto max-w-screen-2xl p-4 md:p-6 2xl:p-10">
                {children}
              </div>
            </div>
          </main>
        </div>
      </div>
    </ThemeProvider>
  );
}
