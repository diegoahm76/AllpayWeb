'use client';
import axios from 'axios';
import { signIn, useSession } from 'next-auth/react';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import '@/presenters/css/background.css';
import { Grid } from '@mui/material';
import { useTheme } from 'next-themes';
import Swal from 'sweetalert2';
import { useRouter } from 'next/navigation';
import UsuarioConfi from '../usuario_configuracion/UsuarioConfi';
import RegisterForm from '@/presenters/components/modules/register/Register';
import AnimatedInput from '@/presenters/components/ui/AnimatedInput';
import AnimatedSelect from '@/presenters/components/ui/AnimatedSelect';
import DynamicTable from '@/presenters/components/ui/DynamicTable';
import { Button } from '@/presenters/components/ui/AnimatedButton';

const baseApiUrl = process.env.BASE_API_URL;
const User: React.FC = () => {
  const router = useRouter();
  interface FormData {
    searchUser1: string;
    searchUser2: string;
    documentNumber: string;
    tipoPersona: string;
    documentType: string;
    firstName: any;
    lastName: any;
    username: any;
  }

  const initialFormData: FormData = {
    searchUser1: '',
    searchUser2: '',
    documentNumber: '',
    tipoPersona: '',
    documentType: '',
    firstName: '',
    lastName: '',
    username: ''
  };

  const fieldTypes: { [key: string]: 'string' } = {
    searchUser1: 'string',
    searchUser2: 'string',
    documentNumber: 'string',
    tipoPersona: 'string',
    documentType: 'string',
    firstName: 'string',
    lastName: 'string',
    username: 'string'
  };

  const [formData, setFormData] = useState<FormData>(initialFormData);

  const resetForm = () => {
    setFormData(initialFormData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | any>) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: fieldTypes[name] === 'string' ? value : value
    }));
  };

  const { data: session, status } = useSession({
    required: true,
    onUnauthenticated() {
      signIn();
    }
  });

  if (status === 'loading') {
    return <div>Cargando...</div>;
  }

  const { theme } = useTheme();

  const valueSesion: any = session;

  const [user, setUser] = useState<any[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  const buscarPersonasAll = async (page = 1): Promise<void> => {
    console.log('Se ejecutó buscarPersonasAll con page:', page);

    const pageNumber = Number(page);
    if (isNaN(pageNumber) || pageNumber < 1) {
      console.error('El valor de "page" no es un número válido:', page);
      await Swal.fire({
        icon: 'warning',
        title: 'Página inválida',
        text: 'El número de página debe ser un número válido mayor a 0.',
        confirmButtonText: 'Aceptar',
        customClass: {
          confirmButton: `
            ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
            hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
            flex items-center justify-center gap-2
          `
        },
        buttonsStyling: false
      });
      return;
    }

    try {
      const url = `${baseApiUrl}personas/get-personas-filters-admin-user/?primer_nombre=${formData.firstName}&primer_apellido=${formData.lastName}&nombre_de_usuario=${formData.username}&numero_documento=${formData.documentNumber}&page=${pageNumber}&tipo_documento=${formData.documentType}&tipo_persona=${formData.tipoPersona}`;

      const response = await axios.get(url, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${valueSesion.user.tokens.access}`
        }
      });

      if (!response.data.success) {
        throw new Error(response.data.detail || 'Error desconocido en la API');
      }

      setUser(response.data.data);
      setTotalPages(response.data.total_pages);
    } catch (error: unknown) {
      console.error('Error en buscarPersonasAll:', error);

      let errorMessage = 'Ocurrió un problema, intenta nuevamente';
      if (error instanceof Error) {
        errorMessage = error.message;
      } else if (typeof error === 'string') {
        errorMessage = error;
      } else if (axios.isAxiosError(error) && error.response?.data?.detail) {
        errorMessage = error.response.data.detail;
      }

      await Swal.fire({
        icon: 'error',
        title: 'Error al obtener los datos',
        text: errorMessage,
        confirmButtonText: 'Aceptar',
        customClass: {
          confirmButton: `
            ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
            hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
            flex items-center justify-center gap-2
          `
        },
        buttonsStyling: false
      });
    } finally {
      setIsLoading(false);
    }
  };

  const [dataTypePerson, setDataTypePerson] = useState([]);
  const obtenerTiposPersona = useCallback(async () => {
    try {
      const response = await axios
        .get(`${baseApiUrl}choices/tipo-persona/`, {
          headers: {
            'Content-Type': 'application/json'
          }
        })
        .catch(function (error) {
          return error.response;
        });
      if (response.data.success === false) {
        throw response.data.detail;
      }
      setDataTypePerson(response.data.data);
    } catch (error) { }
  }, []);

  const [documentTypes, setDocumentTypes] = useState([]);
  const obtenerTiposDocumento = useCallback(async () => {
    try {
      const response = await axios
        .get(`${baseApiUrl}personas/tipos-documento/get-list/?activo=True`, {
          headers: {
            'Content-Type': 'application/json'
          }
        })
        .catch(function (error) {
          return error.response;
        });
      if (response.data.success === false) {
        throw response.data.detail;
      }
      setDocumentTypes(response.data.data);
    } catch (error) { }
  }, []);

  useEffect(() => {
    obtenerTiposPersona();
    obtenerTiposDocumento();
  }, [obtenerTiposPersona, obtenerTiposDocumento]);

  const handleBuscarClick = () => {
    buscarPersonasAll(1);
  };
  useEffect(() => {
    buscarPersonasAll(currentPage);
  }, [currentPage]);

  const buscarPersonasAllExcel = async (): Promise<any[]> => {
    try {
      const url = `${baseApiUrl}personas/get-personas-filters-admin-user/?primer_nombre=${formData.firstName}&primer_apellido=${formData.lastName}&nombre_de_usuario=${formData.username}&numero_documento=${formData.documentNumber}&tipo_documento=${formData.documentType}&tipo_persona=${formData.tipoPersona}`;

      const response = await axios.get(url, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${valueSesion.user.tokens.access}`
        }
      });

      if (!response.data.success) {
        throw new Error(response.data.detail || 'Error desconocido en la API');
      }

      return response.data.data;
    } catch (error: unknown) {
      console.error('Error en buscarPersonasAllExcel:', error);

      let errorMessage = 'Ocurrió un problema, intenta nuevamente';
      if (error instanceof Error) {
        errorMessage = error.message;
      } else if (typeof error === 'string') {
        errorMessage = error;
      } else if (axios.isAxiosError(error) && error.response?.data?.detail) {
        errorMessage = error.response.data.detail;
      }

      await Swal.fire({
        icon: 'error',
        title: 'Error al descargar Excel',
        text: errorMessage,
        confirmButtonText: 'Aceptar',
        customClass: {
          confirmButton: `
            ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
            hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
            flex items-center justify-center gap-2
          `
        },
        buttonsStyling: false
      });

      return [];
    }
  };

  const [
    editar
    //  setEditar
  ] = useState(false);

  const [selectedUser, setSelectedUser] = useState(null);

  const handleEdit = (userData: any) => {
    setSelectedUser(userData);
    console.log('Datos del usuario seleccionado:', userData);
  };

  const [configurar, setconfigurar] = useState(false);
  const [selectedUserr, setSelectedUserr] = useState<{
    nombre_completo: string;
    isActive: boolean;
    id_persona: any;
  } | null>(null);

  const actualizarEstadoUsuario = async () => {
    try {
      await axios.patch(
        `${baseApiUrl}roles/usuarios/actualizar-estado/${selectedUserr?.id_persona}/`,
        {
          is_active: selectedUserr?.isActive
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${valueSesion.user.tokens.access}`
          }
        }
      );

      await Swal.fire({
        icon: 'success',
        title: 'Estado actualizado',
        text: 'El estado del usuario se actualizó correctamente.',
        confirmButtonText: 'Aceptar',
        customClass: {
          confirmButton: `
            ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
            hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
            flex items-center justify-center gap-2 outline-none focus:outline-none
          `
        },
        buttonsStyling: false
      });

      handleBuscarClick();
    } catch (error: unknown) {
      let errorMessage = 'Hubo un error al actualizar el estado.';
      if (axios.isAxiosError(error) && error.response?.data?.detail) {
        errorMessage = error.response.data.detail;
      }

      await Swal.fire({
        icon: 'error',
        title: 'Error al actualizar estado',
        text: errorMessage,
        confirmButtonText: 'Aceptar',
        customClass: {
          confirmButton: `
            ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
            hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
            flex items-center justify-center gap-2 outline-none focus:outline-none
          `
        },
        buttonsStyling: false
      });
    }
  };

  const [tipoUsuario, setTipoUsuario] = useState('');

  const [tipousuario] = useState('interno');

  const [isSuperUsuario, setIsSuperUsuario] = useState<boolean>(false);

  const hasVerified = useRef(false);

  useEffect(() => {
    if (!hasVerified.current) {
      verificarSuperUsuario();
      hasVerified.current = true;
    }
  }, []);

  useEffect(() => {
    if (selectedUserr) {
      // ✅ Verificas si tiene valor
      actualizarEstadoUsuario();
    }
  }, [selectedUserr]);

  const verificarSuperUsuario = async () => {
    try {
      const response = await axios.get(`${baseApiUrl}users/get-superusers/`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${valueSesion?.user?.tokens?.access}`
        }
      });

      if (
        response?.data?.success &&
        response?.data?.data &&
        Array.isArray(response.data.data) &&
        response.data.data.length > 0
      ) {
        const usuario = response.data.data[0];

        // Guardamos el tipo_usuario en el estado
        setTipoUsuario(usuario.tipo_usuario);

        if (usuario.is_superuser === true) {
          await Swal.fire({
            icon: 'success',
            title: '¡Superusuario detectado!',
            text: 'Usted es super usuario.',
            allowOutsideClick: false,
            allowEscapeKey: false,
            confirmButtonText: 'OK',
            customClass: {
              confirmButton: `
                ${'OK'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
                hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
                flex items-center justify-center gap-2 outline-none focus:outline-none
              `
            },
            buttonsStyling: false
          }).then(() => {
            setIsSuperUsuario(true);
          });
        } else {
          setIsSuperUsuario(false);
        }
      } else {
        setIsSuperUsuario(false);
      }
    } catch (error) {
      setIsSuperUsuario(false);
    }
  };

  useEffect(() => {
    if (!hasVerified.current) {
      verificarSuperUsuario();
      hasVerified.current = true;
    }
  }, []);

  useEffect(() => {
    handleBuscarClick();
  }, [configurar]);

  const columns = [
    {
      key: 'tipo_persona_desc',
      label: 'Tipo persona'
    },
    {
      key: 'nombre_completo',
      label: 'Nombre Completo'
    },
    {
      key: 'razon_social',
      label: 'Razón Social'
    },
    {
      key: 'nombre_comercial',
      label: 'Nombre Comercial'
    },
    {
      key: 'tipo_documento',
      label: 'Tipo Documento'
    },
    {
      key: 'numero_documento',
      label: 'N° Documento'
    }
  ];

  const actions = [


    {
      label: 'Editar',
      render: (row: any) => (
        <button
          onClick={() => {
            setconfigurar(!configurar);
            handleEdit(row);
          }}
        >
          <img
            src="https://i.postimg.cc/hPVKjZ05/Grupo-1126.png"
            alt="Editar"
            className="h-6 w-6"
          />
        </button>
      )
    }, {
      label: 'Estado',
      render: (row: any) =>
        !row.is_active && ( // ✅ Solo muestra si `is_active` es false
          <img
            onClick={() => {
              // Solo permite activar si está desactivado
              if (!row.is_active) {
                setSelectedUserr({
                  id_persona: row?.id_persona,
                  nombre_completo: row?.nombre_completo,
                  isActive: true // Solo permite activación
                });
              }
            }}
            src="https://i.postimg.cc/xCycvywm/Grupo-1127.png" // Ícono para inactivos
            alt="Inactivo"
            className="h-6 w-6 cursor-pointer"
          />
        )
    }
    ,
  ];

  return (
    <div className="w-full">
      {configurar ? (
        <>
          <UsuarioConfi
            tipoUsuario={tipoUsuario}
            isSuperUsuario={isSuperUsuario}
            setIsSuperUsuario={setIsSuperUsuario}
            selectedUser={selectedUser}
            setEditar={setconfigurar}
            tipousuario={tipousuario}
          />
        </>
      ) : (
        <>
          {editar ? (
            <>
              <RegisterForm baseApiUrl={baseApiUrl!} tipoUsuario={tipoUsuario} />
              {/* <FormRegisterAdmin setEditar={setEditar} baseApiUrl={baseApiUrl!} /> */}
            </>
          ) : (
            <>
              <div className="flex w-full items-center justify-center md:w-4/4 lg:w-2/2">
                <div className="w-full p-1">
                  <div
                    className={`m-auto w-full rounded-xl p-6 ${theme === 'dark' ? 'bg-opacity-10 bg-[#78390e]' : 'bg-slate-200'}`}
                  >
                    <div className={`rounded-xl p-4 ${theme === 'dark' ? 'dark' : 'bg-white'}`}>
                      <div>
                        <h3
                          className={`mt-[39px] mb-10 text-center text-3xl font-bold ${theme === 'dark' ? 'text-white' : 'text-[#562707]'}`}
                        >
                          Administrar Usuarios
                        </h3>
                      </div>
                      <div className="grid gap-4 md:grid-cols-2">
                        <div></div>
                      </div>

                      <Grid container spacing={2} className="mb-4">
                        <Grid item xs={12} sm={6} md={4} lg={4} xl={4}>
                          <AnimatedInput
                            type="text"
                            name="firstName"
                            id="firstName"
                            label="Primer Nombre"
                            value={formData.firstName}
                            onChange={handleChange}
                          />
                        </Grid>

                        <Grid item xs={12} sm={6} md={4} lg={4} xl={4}>
                          <AnimatedInput
                            type="text"
                            name="lastName"
                            id="lastName"
                            label="Primer Apellido"
                            value={formData.lastName}
                            onChange={handleChange}
                          />
                        </Grid>

                        <Grid item xs={12} sm={6} md={4} lg={4} xl={4}>
                          <AnimatedInput
                            type="text"
                            name="username"
                            id="username"
                            label="Nombre de Usuario"
                            value={formData.username}
                            onChange={handleChange}
                          />
                        </Grid>

                        <Grid item xs={12} sm={6} md={4} lg={4} xl={4}>
                          <div>
                            <AnimatedSelect
                              label="Tipo de Persona"
                              name="tipoPersona"
                              value={formData.tipoPersona}
                              onChange={handleChange}
                              options={dataTypePerson.map((value: any, index: number) => ({
                                key: index,
                                value: value[0],
                                title: value[1]
                              }))}
                            />
                          </div>
                        </Grid>

                        <Grid item xs={12} sm={6} md={4} lg={4} xl={4}>
                          <div>
                            <AnimatedSelect
                              label="Tipo de Documento"
                              name="documentType"
                              value={formData.documentType}
                              onChange={handleChange}
                              options={documentTypes.map((value: any, index: number) => ({
                                key: index,
                                value: value.cod_tipo_documento,
                                title: value.nombre
                              }))}
                            />
                          </div>
                        </Grid>

                        <Grid item xs={12} sm={6} md={4} lg={4} xl={4} marginTop={0}>
                          <div>
                            <AnimatedInput
                              type="text"
                              name="documentNumber"
                              id="documentNumber"
                              label="Número de Documento"
                              value={formData.documentNumber}
                              onChange={handleChange}
                            />
                          </div>
                        </Grid>
                      </Grid>

                      <Grid container spacing={2} className="mb-4 justify-center overflow-x-auto">
                        <Grid item>
                          <div className="">
                            <Button title="Buscar" onClick={() => handleBuscarClick()} />
                          </div>
                        </Grid>

                        <Grid item>
                          <div className="">
                            <Button title="Limpiar" onClick={() => resetForm()} />
                          </div>
                        </Grid>

                        <Grid item>
                          <div className="">
                            <Button title="Salir" onClick={() => router.push('/')}
                            />
                          </div>
                        </Grid>
                      </Grid>
                    </div>

                    <div
                      className={`mt-7 rounded-xl p-4 ${theme === 'dark' ? 'dark' : 'bg-white'}`}
                    >


                      <h3
                        className={`mt-[39px]  text-center text-3xl font-bold ${theme === 'dark' ? 'text-white' : 'text-[#562707]'}`}
                      >
                        Búsqueda avanzada por persona
                      </h3>


                      <Grid
                        container
                        spacing={2}
                        marginTop={2}
                        marginLeft={-1}
                        direction="row"
                        sx={{
                          justifyContent: 'space-around',
                          alignItems: 'center'
                        }}
                      >
                        <DynamicTable
                          columns={columns}
                          data={user}
                          currentPage={currentPage}
                          totalPages={totalPages}
                          onPageChange={setCurrentPage}
                          actions={actions}
                          isLoading={isLoading}
                          onDownloadExcel={buscarPersonasAllExcel}
                        />
                      </Grid>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
};

export default User;
