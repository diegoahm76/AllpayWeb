'use client';

import React from 'react';
import DniTable from '@/adapters/modules/dni/DniTable';

const DniPage: React.FC = () => {
    return <DniTable />;
};

export default DniPage; 