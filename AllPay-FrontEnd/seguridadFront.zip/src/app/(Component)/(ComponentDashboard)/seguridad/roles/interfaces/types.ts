export interface PermisoData {
    value: boolean;
    id: number;
};

export interface Modulo {
    id_modulo: number;
    nombre_modulo: string;
    descripcion: string;
    ruta_formulario: string;
    nombre_icono: string;
    permisos: Record<string, PermisoData>;
};

export interface Rol {
    subsistema: string;
    desc_subsistema: string;
    modulos: Modulo[];
};

export interface RolesCrearProps {
    setShowMessage?: any;
    selectedRolId?: any;
}


export interface FormData {
    searchUser1: string;
    searchUser2: string;
    tipoPersona: string;
    nombrerol: string;
    descripcion: string;
}