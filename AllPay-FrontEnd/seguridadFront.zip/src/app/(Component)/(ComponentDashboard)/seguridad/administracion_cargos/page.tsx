'use client';
import axios from 'axios';
import { signIn, useSession } from 'next-auth/react';
import React, { useEffect, useState } from 'react';
import '@/presenters/css/background.css';
import { useTheme } from 'next-themes';
import Swal from 'sweetalert2';
import AnimatedInput from '@/presenters/components/ui/AnimatedInput';
import DynamicTable from '@/presenters/components/ui/DynamicTable';
import ModalContainer from '@/presenters/components/ui/ModalContainer';
import { Button } from '@/presenters/components/ui/AnimatedButton';
import { useRouter } from 'next/navigation';

const baseApiUrl = process.env.BASE_API_URL;
const Administracion_cargos: React.FC = () => {
  const router = useRouter();
  interface FormData {
    nombre: any;
  }

  const initialFormData: FormData = {
    nombre: ''
  };

  const fieldTypes: { [key: string]: 'string' } = {
    nombre: 'string'
  };

  const [formData, setFormData] = useState<FormData>(initialFormData);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | any>) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: fieldTypes[name] === 'string' ? value : value
    }));
  };

  const { data: session, status } = useSession({
    required: true,
    onUnauthenticated() {
      signIn();
    }
  });

  if (status === 'loading') {
    return <div>Cargando...</div>;
  }

  const { theme } = useTheme();

  const valueSesion: any = session;

  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  const [user, setUser] = useState<any[]>([]);

  const buscarPersonasAll = async (page = 1): Promise<void> => {

    console.log('Se ejecutó buscarPersonasAll con page:', page);

    const pageNumber = Number(page);
    if (isNaN(pageNumber) || pageNumber < 1) {
      console.error('El valor de "page" no es un número válido:', page);
      Swal.fire({
        icon: 'warning',
        title: 'Página inválida',
        text: 'El número de página debe ser un número válido mayor a 0.'
      });
      return;
    }

    try {
      const url = `${baseApiUrl}personas/cargos/get-list/`;

      const response = await axios.get(url, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${valueSesion.user.tokens.access}`
        }
      });

      if (!response.data.success) {
        throw new Error(response.data.detail || 'Error desconocido en la API');
      }

      setUser(response.data.data);
      setTotalPages(response.data.total_pages);
    } catch (error: unknown) {
      console.error('Error en buscarPersonasAll:', error);

      let errorMessage = 'Ocurrió un problema, intenta nuevamente';
      if (error instanceof Error) {
        errorMessage = error.message;
      } else if (typeof error === 'string') {
        errorMessage = error;
      } else if (axios.isAxiosError(error) && error.response?.data?.detail) {
        errorMessage = error.response.data.detail;
      }

      Swal.fire({
        icon: 'error',
        title: 'Error al obtener los datos',
        text: errorMessage
      });
    } finally {
      setIsLoading(false);
    }
  };

  const columns = [{ key: 'nombre', label: 'Nombre' }];

  const actions = [
    {
      label: 'Editar',
      render: (row: any) => (
        <button
          onClick={() => {
            handleEdit(row);
            setShowModal(true);
          }}
        >
          <img
            src="https://i.postimg.cc/hPVKjZ05/Grupo-1126.png"
            alt="Editar"
            className="h-6 w-6"
          />
        </button>
      )
    },
    {
      label: 'Eliminar',
      render: (row: any) => (
        <button onClick={() => handleDeleteCargo(row.id_cargo)}>
          <img
            src="https://i.postimg.cc/26tZCTC3/Grupo-1125-1.png"
            alt="Eliminar"
            className="h-6 w-6"
          />
        </button>
      )
    }
  ];

  useEffect(() => {
    buscarPersonasAll(currentPage);
  }, [currentPage]);

  const handleCreateCargo = async () => {
    if (!formData.nombre.trim()) {
      await Swal.fire({
        icon: 'warning',
        title: 'Campo requerido',
        text: 'Debes ingresar un nombre para el cargo.',
        confirmButtonText: 'Aceptar',
        customClass: {
          confirmButton: `
            ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
            hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
            flex items-center justify-center gap-2
          `
        },
        buttonsStyling: false
      });
      return;
    }

    try {
      const response = await axios.post(
        `${baseApiUrl}personas/cargos/create/`,
        { nombre: formData.nombre },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${valueSesion.user.tokens.access}`
          }
        }
      );

      if (response.data.success) {
        await Swal.fire({
          icon: 'success',
          title: '¡Cargo creado!',
          text: 'El nuevo cargo se ha creado correctamente.',
          confirmButtonText: 'Aceptar',
          customClass: {
            confirmButton: `
              ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
              hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
              flex items-center justify-center gap-2
            `
          },
          buttonsStyling: false
        });

        buscarPersonasAll();
        setFormData((prev) => ({ ...prev, nombre: '' }));
        setShowModalcrear(false);
      } else {
        await Swal.fire({
          icon: 'error',
          title: 'Error',
          text: response.data.detail || 'Ocurrió un error al crear el cargo.',
          confirmButtonText: 'Aceptar',
          customClass: {
            confirmButton: `
              ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
              hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
              flex items-center justify-center gap-2
            `
          },
          buttonsStyling: false
        });
      }
    } catch (error: any) {
      const mensaje = error?.response?.data?.detail || 'Ocurrió un error al crear el cargo.';
      await Swal.fire({
        icon: 'error',
        title: 'Error',
        text: mensaje,
        confirmButtonText: 'Aceptar',
        customClass: {
          confirmButton: `
            ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
            hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
            flex items-center justify-center gap-2
          `
        },
        buttonsStyling: false
      });
    }
  };

  const [selectedId, setSelectedId] = useState<number | null>(null);

  const handleEdit = (user: any) => {
    setFormData({
      nombre: user.nombre
    });
    setSelectedId(user.id_cargo);
  };

  const [showModal, setShowModal] = useState(false);
  const [showModalcrear, setShowModalcrear] = useState(false);

  useEffect(() => {
    if (!showModal) {
      setFormData((prev) => ({
        ...prev,
        nombre: ''
      }));
    }
  }, [showModal]);

  const handleUpdateCargo = async () => {
    if (!formData.nombre.trim()) {
      await Swal.fire({
        icon: 'warning',
        title: 'Campo requerido',
        text: 'Debes ingresar un nombre para el cargo.',
        confirmButtonText: 'Aceptar',
        customClass: {
          confirmButton: `
            ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
            hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
            flex items-center justify-center gap-2
          `
        },
        buttonsStyling: false
      });
      return;
    }

    if (!selectedId) return;

    try {
      const response = await axios.put(
        `${baseApiUrl}personas/cargos/update/${selectedId}/`,
        { nombre: formData.nombre },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${valueSesion.user.tokens.access}`
          }
        }
      );

      if (response.data.success) {
        await Swal.fire({
          icon: 'success',
          title: '¡Cargo actualizado!',
          text: 'El cargo ha sido editado correctamente.',
          confirmButtonText: 'Aceptar',
          customClass: {
            confirmButton: `
              ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
              hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
              flex items-center justify-center gap-2
            `
          },
          buttonsStyling: false
        });

        buscarPersonasAll();
        setShowModal(false);
        setFormData(initialFormData);
        setSelectedId(null);
      } else {
        await Swal.fire({
          icon: 'error',
          title: 'Error',
          text: response.data.detail || 'Ocurrió un error al actualizar el cargo.',
          confirmButtonText: 'Aceptar',
          customClass: {
            confirmButton: `
              ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
              hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
              flex items-center justify-center gap-2
            `
          },
          buttonsStyling: false
        });
      }
    } catch (error: any) {
      const mensaje = error?.response?.data?.detail || 'Ocurrió un error al actualizar el cargo.';
      await Swal.fire({
        icon: 'error',
        title: 'Error',
        text: mensaje,
        confirmButtonText: 'Aceptar',
        customClass: {
          confirmButton: `
            ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
            hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
            flex items-center justify-center gap-2
          `
        },
        buttonsStyling: false
      });
    }
  };

  const handleDeleteCargo = async (id: number) => {
    const confirm = await Swal.fire({
      title: '¿Estás seguro?',
      text: 'Esta acción eliminará el cargo permanentemente.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, eliminar',
      cancelButtonText: 'Cancelar',
      reverseButtons: true, // <--- esto invierte el orden
      customClass: {
        actions: 'flex gap-4 justify-end', // espacio entre botones
        confirmButton: `
        ${'Sí, eliminar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
        hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
        flex items-center justify-center gap-2
      `,
        cancelButton: `
        ${'Cancelar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
        hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
        flex items-center justify-center gap-2
      `
      },
      buttonsStyling: false
    });

    if (confirm.isConfirmed) {
      try {
        const response = await axios.delete(`${baseApiUrl}personas/cargos/delete/${id}/`, {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${valueSesion.user.tokens.access}`
          }
        });

        if (response.data.success) {
          await Swal.fire({
            icon: 'success',
            title: '¡Eliminado!',
            text: 'El cargo ha sido eliminado correctamente.',
            confirmButtonText: 'Aceptar',
            customClass: {
              confirmButton: `
              ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
              hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
              flex items-center justify-center gap-2
            `
            },
            buttonsStyling: false
          });

          buscarPersonasAll();
        } else {
          await Swal.fire({
            icon: 'error',
            title: 'Error',
            text: response.data.detail || 'No se pudo eliminar el cargo.',
            confirmButtonText: 'Aceptar',
            customClass: {
              confirmButton: `
              ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
              hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
              flex items-center justify-center gap-2
            `
            },
            buttonsStyling: false
          });
        }
      } catch (error: any) {
        const mensaje = error?.response?.data?.detail || 'Ocurrió un error al eliminar el cargo.';
        await Swal.fire({
          icon: 'error',
          title: 'Error',
          text: mensaje,
          confirmButtonText: 'Aceptar',
          customClass: {
            confirmButton: `
            ${'Aceptar'.trim().split(/\s+/).length === 1 ? 'w-[120px]' : 'px-6'} py-2 rounded-2xl bg-[rgb(var(--green))] text-white transition-all duration-300
            hover:bg-[rgb(var(--green-80))] disabled:bg-[rgb(var(--gray-40))] disabled:cursor-not-allowed cursor-pointer
            flex items-center justify-center gap-2
          `
          },
          buttonsStyling: false
        });
      }
    }
  };

  const handleDownloadExcel = async () => {
    try {
      const response = await axios.get(`${baseApiUrl}personas/cargos/get-list/`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${valueSesion.user.tokens.access}`
        }
      });

      if (!response.data.success) {
        throw new Error(response.data.detail || 'Error desconocido en la API');
      }

      const data = response.data.data;
      if (!data || data.length === 0) {
        return [];
      }

      return data.map((item: any) => ({
        'Nombre': item.nombre
      }));
    } catch (error) {
      console.error('Error al obtener datos para Excel:', error);
      return [];
    }
  };

  return (
    <div className="w-full">
      <div className="flex w-full items-center justify-center md:w-4/4 lg:w-2/2">
        <div className="w-full p-1">
          <div
            className={`m-auto w-full rounded-xl p-6 ${theme === 'dark' ? 'bg-opacity-10 bg-[#78390e]' : 'bg-slate-200'}`}
          >
            <div className={`rounded-xl p-4 ${theme === 'dark' ? 'dark' : 'bg-white'}`}>

              <div className="relative  mt-[39px] flex items-center justify-center">
                <h3
                  className={`text-center text-3xl font-bold ${theme === 'dark' ? 'text-white' : 'text-[#562707]'}`}
                >
                  Tipos de Cargos
                </h3>

              </div>

              <DynamicTable
                columns={columns}
                data={user}
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
                actions={actions}
                isLoading={isLoading}
                onDownloadExcel={handleDownloadExcel}
              />

              <div className='flex justify-center mt-6 space-x-4'>
                <div >
                  <Button onClick={() => router.push('/')} title="Salir" />
                </div>
                <div >
                  <Button onClick={() => setShowModalcrear(true)} title="Crear" />
                </div>

              </div>

            </div>
          </div>
        </div>
      </div>

      <ModalContainer isOpen={showModal} onClose={() => setShowModal(false)}>
        <div className="space-y-4">
          <h3
            className={`mb-4 text-center text-xl font-bold ${theme === 'dark' ? 'text-white' : 'text-[#562707]'}`}
          >
            Editar Tipo de Cargo
          </h3>

          <AnimatedInput
            type="text"
            name="nombre"
            id="nombre"
            label="  Nombre de cargo"
            value={formData.nombre}
            onChange={handleChange}
          />

          <div className="mt-6 flex justify-end space-x-4">
            <Button onClick={() => setShowModal(false)} title="Cancelar"></Button>
            <Button onClick={handleUpdateCargo} title="Editar"></Button>
          </div>
        </div>
      </ModalContainer>

      <ModalContainer isOpen={showModalcrear} onClose={() => setShowModalcrear(false)}>
        <div className="space-y-4">
          <h3
            className={`mb-4 text-center text-xl font-bold ${theme === 'dark' ? 'text-white' : 'text-[#562707]'}`}
          >
            Editar Tipo de Cargo
          </h3>

          <AnimatedInput
            type="text"
            name="nombre"
            id="nombre"
            label="  Nombre de cargo"
            value={formData.nombre}
            onChange={handleChange}
          />

          <div className="mt-6 flex justify-end space-x-4">
            <Button title="Cancelar" onClick={() => setShowModalcrear(false)}></Button>
            <Button title=" Crear Cargo " onClick={handleCreateCargo}></Button>
          </div>
        </div>
      </ModalContainer>

    </div>
  );
};

export default Administracion_cargos;
