'use client';
import axios from 'axios';
import { signIn, useSession } from 'next-auth/react';
import React, { useEffect, useState } from 'react';
import '@/presenters/css/background.css';
import RegisterForm from '@/presenters/components/modules/register/Register';

const baseApiUrl = process.env.BASE_API_URL;
const User: React.FC = () => {

  const { data: session, status } = useSession({
    required: true,
    onUnauthenticated() {
      signIn();
    }
  });

  if (status === 'loading') {
    return <div>Cargando...</div>;
  }

  const valueSesion: any = session;

  const [tipoUsuario, setTipoUsuario] = useState('');

  const obtenerSuperUsuario = async () => {
    try {
      const response = await axios.get(`${baseApiUrl}users/get-superusers/`, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${valueSesion?.user?.tokens?.access}`
        }
      });

      const data = response?.data?.data;

      if (response?.data?.success && Array.isArray(data) && data.length > 0) {
        setTipoUsuario(data[0].tipo_usuario);
      } else {
        setTipoUsuario('No encontrado');
      }
    } catch (error) {
      setTipoUsuario('Error al obtener');
    }
  };

  useEffect(() => {
    obtenerSuperUsuario();
  }, []);
  const [app] = useState(true);

  return (
    <>
      <RegisterForm baseApiUrl={baseApiUrl!} tipoUsuario={tipoUsuario} app={app} />
    </>
  );
};

export default User;
