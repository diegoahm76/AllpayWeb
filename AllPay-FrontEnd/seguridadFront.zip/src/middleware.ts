export { auth as middleware } from './auth';

// Read more: https://nextjs.org/docs/app/building-your-application/routing/middleware#matcher
export const config = {
  matcher: ['/((?!api|_next/static|_next/image|images|icon.png|favicon.ico).*)']
};

// When user is not logged in and tries to access protected routes redirect to login page
export const DEFAULT_REDIRECT_LOGIN_URL = '/auth/signin';

// When user is logged in and tries to access login page redirect to dashboard

export const DEFAULT_REDIRECT_HOME_URL = '/';

